# AdaptFit

Adaptive fitness app for Android (Kotlin + Jetpack Compose). All data stays on the phone.

Build: `gradle testDebugUnitTest assembleDebug` (Gradle 8.9, JDK 17).
APK: app/build/outputs/apk/debug/app-debug.apk
