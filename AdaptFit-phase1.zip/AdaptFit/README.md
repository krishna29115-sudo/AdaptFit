# AdaptFit — Accessible Fitness for Everyone
Native Android (Kotlin, Compose, Material 3, Room, DataStore). Offline-first, no ads, no network.

## Build
- Android Studio (Koala+): open this folder, press Run.
- Or CLI with Gradle 8.9+ and JDK 17: `gradle assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk
- No tooling: push to GitHub; the "Build APK" Action uploads app-debug.apk as an artifact.

## Status
Phase 1 done (setup, theme, nav, Room profile, accessibility settings). Other tabs are marked unbuilt until their phase.
