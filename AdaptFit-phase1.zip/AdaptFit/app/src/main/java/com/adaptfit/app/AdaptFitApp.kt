package com.adaptfit.app

import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.adaptfit.app.data.db.AppDatabase
import com.adaptfit.app.data.prefs.SettingsStore
import com.adaptfit.app.data.repo.ProfileRepository
import com.adaptfit.app.ui.profile.ProfileViewModel

/** Simple manual DI container; swap for Hilt later if desired. */
class AppContainer(context: Context) {
    private val db = AppDatabase.create(context)
    val settings = SettingsStore(context)
    val profileRepo = ProfileRepository(db.profileDao())
}

class AdaptFitApp : Application() {
    lateinit var container: AppContainer
    override fun onCreate() { super.onCreate(); container = AppContainer(this) }
}

class VMFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(ProfileViewModel::class.java) -> ProfileViewModel(c.profileRepo) as T
        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    }
}
