package com.adaptfit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adaptfit.app.data.prefs.AppSettings
import com.adaptfit.app.ui.nav.AdaptFitNav
import com.adaptfit.app.ui.theme.AdaptFitTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as AdaptFitApp).container
        setContent {
            val s by container.settings.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
            AdaptFitTheme(s) { AdaptFitNav(container) }
        }
    }
}
