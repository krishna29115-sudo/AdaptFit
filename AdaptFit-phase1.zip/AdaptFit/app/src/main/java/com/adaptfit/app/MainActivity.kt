package com.adaptfit.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val state = AppState(getSharedPreferences("adaptfit", MODE_PRIVATE))
        setContent {
            AdaptFitApp(state)
        }
    }
}

@Composable
fun AdaptFitApp(state: AppState) {
    val context = LocalContext.current
    val speaker = remember { Speaker(context) }
    DisposableEffect(Unit) {
        onDispose { speaker.shutdown() }
    }
    AdaptFitTheme(state.settings) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (!state.profile.onboarded) {
                OnboardingScreen(state)
            } else {
                MainScaffold(state, speaker)
            }
        }
    }
}

@Composable
fun MainScaffold(state: AppState, speaker: Speaker) {
    var tab by remember { mutableIntStateOf(0) }
    var immersive by remember { mutableStateOf(false) }
    val tabs = listOf(
        "Home" to "🏠",
        "Workout" to "💪",
        "Progress" to "📈",
        "Profile" to "👤",
        "Settings" to "⚙️"
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (!immersive) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    tabs.forEachIndexed { i, t ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(t.second) },
                            label = { Text(t.first) },
                            alwaysShowLabel = true
                        )
                    }
                }
            }
        }
    ) { pad ->
        Box(modifier = Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(state) { tab = 1 }
                1 -> WorkoutScreen(state, speaker) { immersive = it }
                2 -> ProgressScreen(state)
                3 -> ProfileScreen(state)
                else -> SettingsScreen(state)
            }
        }
    }
}
