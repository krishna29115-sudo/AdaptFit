package com.adaptfit.app

enum class Mobility(val label: String, val help: String) {
    SEATED("Seated only", "I exercise from a chair or wheelchair"),
    LIMITED("Limited standing", "I can stand for short periods with support"),
    FULL("Full mobility", "I can stand and move freely")
}

enum class Limitation(val label: String) {
    UPPER("Limited arm or shoulder movement"),
    GRIP("Weak grip or hand strength"),
    BALANCE("Balance difficulty"),
    JOINT("Joint pain or stiffness"),
    STAMINA("I tire easily")
}

enum class Equipment(val label: String) {
    BAND("Resistance band"),
    WEIGHTS("Light weights or water bottles"),
    CHAIR("Sturdy chair or counter for support")
}

enum class Goal(val label: String) {
    STRENGTH("Get stronger"),
    MOBILITY("Move more easily"),
    ENDURANCE("Build stamina"),
    RELAX("Relax and stretch")
}

data class Profile(
    val name: String = "",
    val age: Int = 0,
    val heightCm: Float = 0f,
    val weightKg: Float = 0f,
    val mobility: Mobility = Mobility.SEATED,
    val limitations: Set<Limitation> = emptySet(),
    val equipment: Set<Equipment> = emptySet(),
    val goals: Set<Goal> = setOf(Goal.MOBILITY),
    val weeklyTarget: Int = 3,
    val onboarded: Boolean = false
)

data class Settings(
    val textSize: Int = 0,
    val highContrast: Boolean = false,
    val reduceMotion: Boolean = false,
    val voice: Boolean = false,
    val haptics: Boolean = true,
    val metric: Boolean = true,
    val theme: Int = 0
)

data class Session(val day: Long, val minutes: Int, val exercises: Int, val title: String)

data class Exercise(
    val name: String,
    val how: String,
    val goal: Goal,
    val seconds: Int,
    val minMobility: Mobility = Mobility.SEATED,
    val upper: Boolean = false,
    val grip: Boolean = false,
    val balance: Boolean = false,
    val joint: Boolean = false,
    val equipment: Equipment? = null
)

data class Step(val exercise: Exercise, val workSeconds: Int, val restSeconds: Int)

data class Segment(
    val title: String,
    val text: String,
    val seconds: Int,
    val rest: Boolean,
    val stepNo: Int,
    val total: Int
)

val EXERCISES: List<Exercise> = listOf(
    Exercise("Seated deep breathing", "Sit tall. Breathe in slowly through your nose, then out through your mouth.", Goal.RELAX, 45),
    Exercise("Seated shoulder rolls", "Roll your shoulders up, back and down in slow, smooth circles.", Goal.RELAX, 30, upper = true),
    Exercise("Gentle neck stretch", "Slowly tilt your ear toward one shoulder, hold, then switch sides. Keep it gentle.", Goal.RELAX, 40),
    Exercise("Seated forward fold", "Sit tall, then lean forward from your hips and let your arms hang. Stop if it hurts.", Goal.RELAX, 30),
    Exercise("Seated torso twist", "Sit tall and turn your upper body gently to one side, then the other.", Goal.MOBILITY, 40),
    Exercise("Seated arm circles", "Hold your arms out to the sides and make small circles, then reverse.", Goal.MOBILITY, 30, upper = true),
    Exercise("Seated overhead reach", "Reach one arm up toward the ceiling, then the other, in a slow rhythm.", Goal.MOBILITY, 30, upper = true),
    Exercise("Seated ankle circles", "Lift one foot slightly and circle your ankle. Switch feet halfway.", Goal.MOBILITY, 40),
    Exercise("Seated march", "Lift one knee, then the other, like marching. Keep a steady rhythm.", Goal.ENDURANCE, 45),
    Exercise("Seated punches", "Punch forward with one hand, then the other. Breathe out with each punch.", Goal.ENDURANCE, 40, upper = true),
    Exercise("Seated knee extensions", "Straighten one leg out in front of you, hold for a moment, then lower it. Alternate legs.", Goal.STRENGTH, 40),
    Exercise("Seated band row", "Loop the band around your feet. Pull it toward your ribs, squeeze, and release slowly.", Goal.STRENGTH, 40, upper = true, grip = true, equipment = Equipment.BAND),
    Exercise("Seated band pull-apart", "Hold the band at chest height. Pull your hands apart, then return slowly.", Goal.STRENGTH, 40, upper = true, grip = true, equipment = Equipment.BAND),
    Exercise("Seated shoulder press", "Hold a light weight in each hand at shoulder height. Press upward, then lower slowly.", Goal.STRENGTH, 40, upper = true, grip = true, equipment = Equipment.WEIGHTS),
    Exercise("Seated bicep curls", "Hold a light weight in each hand. Bend your elbows, then lower slowly.", Goal.STRENGTH, 40, upper = true, grip = true, equipment = Equipment.WEIGHTS),
    Exercise("Supported sit-to-stand", "Stand up from a sturdy chair, using your hands for support if needed. Then sit down slowly.", Goal.STRENGTH, 40, Mobility.LIMITED, joint = true, equipment = Equipment.CHAIR),
    Exercise("Supported calf raises", "Hold a chair or counter. Rise onto your toes, then lower slowly.", Goal.STRENGTH, 35, Mobility.LIMITED, balance = true, equipment = Equipment.CHAIR),
    Exercise("Supported side leg lifts", "Hold a chair. Lift one leg out to the side, lower it, then switch legs.", Goal.MOBILITY, 40, Mobility.LIMITED, balance = true, equipment = Equipment.CHAIR),
    Exercise("Supported hamstring stretch", "Hold a chair. Rest one heel on the floor in front of you and lean forward gently. Switch legs halfway.", Goal.RELAX, 40, Mobility.LIMITED, balance = true, equipment = Equipment.CHAIR),
    Exercise("March on the spot", "Lift your knees one at a time and swing your arms. Keep a steady pace.", Goal.ENDURANCE, 50, Mobility.FULL, balance = true),
    Exercise("Step touches", "Step to one side, bring your feet together, then step to the other side.", Goal.ENDURANCE, 50, Mobility.FULL, balance = true),
    Exercise("Wall push-ups", "Stand facing a wall. Place your hands on it and bend your elbows to lean in, then push back.", Goal.STRENGTH, 35, Mobility.FULL, upper = true),
    Exercise("Bodyweight squats", "Feet shoulder-width apart. Sit your hips back and down, then stand up tall.", Goal.STRENGTH, 35, Mobility.FULL, joint = true),
    Exercise("Standing side bends", "Stand tall. Slide one hand down your leg as you lean to the side, then switch.", Goal.MOBILITY, 35, Mobility.FULL)
)

fun <T> List<T>.rotate(k: Int): List<T> {
    if (isEmpty()) return this
    val n = ((k % size) + size) % size
    return drop(n) + take(n)
}

fun eligible(p: Profile): List<Exercise> = EXERCISES.filter { e ->
    p.mobility.ordinal >= e.minMobility.ordinal &&
        !(e.upper && Limitation.UPPER in p.limitations) &&
        !(e.grip && Limitation.GRIP in p.limitations) &&
        !(e.balance && Limitation.BALANCE in p.limitations) &&
        !(e.joint && Limitation.JOINT in p.limitations) &&
        (e.equipment == null || e.equipment in p.equipment)
}

fun buildPlan(p: Profile, mainCount: Int, seed: Int): List<Step> {
    val pool = eligible(p)
    val tired = Limitation.STAMINA in p.limitations
    val warm = pool.filter { it.goal == Goal.MOBILITY }.rotate(seed).take(2)
    val cool = pool.filter { it.goal == Goal.RELAX }.rotate(seed).take(1)
    val used = warm + cool
    val wanted = if (tired) (mainCount - 1).coerceAtLeast(2) else mainCount
    val preferred = pool.filter { it.goal in p.goals && it !in used }.rotate(seed)
    val others = pool.filter { it !in used && it !in preferred }.rotate(seed)
    val main = (preferred + others).take(wanted)
    val all = (warm + main + cool).distinctBy { it.name }
    val rest = if (tired) 25 else 12
    return all.mapIndexed { i, e ->
        val work = if (tired) (e.seconds * 7 / 10).coerceAtLeast(20) else e.seconds
        Step(e, work, if (i == all.lastIndex) 0 else rest)
    }
}

fun planMinutes(steps: List<Step>): Int =
    (steps.sumOf { it.workSeconds + it.restSeconds } + 59) / 60

fun toSegments(steps: List<Step>): List<Segment> {
    val out = mutableListOf<Segment>()
    steps.forEachIndexed { i, s ->
        out.add(Segment(s.exercise.name, s.exercise.how, s.workSeconds, false, i + 1, steps.size))
        if (s.restSeconds > 0 && i < steps.lastIndex) {
            out.add(Segment("Rest", "Next: " + steps[i + 1].exercise.name, s.restSeconds, true, i + 1, steps.size))
        }
    }
    return out
}
