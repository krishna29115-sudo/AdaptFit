package com.adaptfit.app

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private fun fmt(v: Float): String = String.format(Locale.US, "%.1f", v).removeSuffix(".0")

private fun parseNum(t: String): Float? = t.trim().replace(',', '.').toFloatOrNull()

private val TIPS = listOf(
    "Slow and steady wins. Move at a pace that feels comfortable today.",
    "Drink some water before and after you move.",
    "Short sessions count. Five minutes is better than none.",
    "Breathe out during the effort part of each move.",
    "Rest days help your body get stronger.",
    "Stop and rest if anything hurts, feels dizzy, or leaves you short of breath.",
    "Notice how you feel afterwards, not just how you did."
)

/* ---------------------------------------------------------------- Onboarding */

@Composable
fun OnboardingScreen(state: AppState) {
    var step by remember { mutableIntStateOf(0) }
    var agreed by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var mobility by remember { mutableStateOf(Mobility.SEATED) }
    var limitations by remember { mutableStateOf(emptySet<Limitation>()) }
    var equipment by remember { mutableStateOf(emptySet<Equipment>()) }
    var goals by remember { mutableStateOf(setOf(Goal.MOBILITY)) }
    var target by remember { mutableIntStateOf(3) }
    val lastStep = 4

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Step ${step + 1} of ${lastStep + 1}", style = MaterialTheme.typography.bodyMedium)
            when (step) {
                0 -> {
                    Title("Welcome to AdaptFit")
                    Text(
                        "Exercise that adapts to your body. Tell us a little about yourself and we will build workouts that suit you.",
                        style = MaterialTheme.typography.bodyLarge
                    )
                    AppCard {
                        Text("Please read", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "AdaptFit gives general fitness ideas. It is not medical advice. Please check with your doctor or physiotherapist before you start. Stop straight away if you feel pain, dizziness, or shortness of breath.",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 56.dp)
                            .toggleable(value = agreed, role = Role.Checkbox, onValueChange = { agreed = it }),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = agreed, onCheckedChange = null)
                        Spacer(Modifier.width(12.dp))
                        Text("I understand and want to continue", style = MaterialTheme.typography.titleMedium)
                    }
                }
                1 -> {
                    Title("What should we call you?")
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Your name (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                2 -> {
                    Title("How do you move?")
                    SingleSelect(
                        items = Mobility.values().toList(),
                        selected = mobility,
                        label = { it.label },
                        help = { it.help },
                        onSelect = { mobility = it }
                    )
                    Text("Anything we should work around? Tick all that apply.", style = MaterialTheme.typography.titleMedium)
                    MultiSelect(
                        items = Limitation.values().toList(),
                        selected = limitations,
                        label = { it.label },
                        onChange = { limitations = it }
                    )
                }
                3 -> {
                    Title("What do you have at home?")
                    Text("No equipment is fine. Leave everything unticked.", style = MaterialTheme.typography.bodyLarge)
                    MultiSelect(
                        items = Equipment.values().toList(),
                        selected = equipment,
                        label = { it.label },
                        onChange = { equipment = it }
                    )
                }
                else -> {
                    Title("What are your goals?")
                    MultiSelect(
                        items = Goal.values().toList(),
                        selected = goals,
                        label = { it.label },
                        onChange = { goals = it }
                    )
                    Text("How many days a week?", style = MaterialTheme.typography.titleMedium)
                    SingleSelect(
                        items = listOf(2, 3, 4, 5),
                        selected = target,
                        label = { "$it days a week" },
                        onSelect = { target = it }
                    )
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (step > 0) {
                OutlinedButton(
                    onClick = { step -= 1 },
                    modifier = Modifier.weight(1f).heightIn(min = 56.dp)
                ) { Text("Back") }
            }
            Button(
                onClick = {
                    if (step < lastStep) {
                        step += 1
                    } else {
                        state.saveProfile(
                            state.profile.copy(
                                name = name.trim(),
                                mobility = mobility,
                                limitations = limitations,
                                equipment = equipment,
                                goals = goals,
                                weeklyTarget = target,
                                onboarded = true
                            )
                        )
                    }
                },
                enabled = when (step) {
                    0 -> agreed
                    lastStep -> goals.isNotEmpty()
                    else -> true
                },
                modifier = Modifier.weight(1f).heightIn(min = 56.dp)
            ) { Text(if (step < lastStep) "Next" else "Finish") }
        }
    }
}

/* ---------------------------------------------------------------------- Home */

@Composable
fun HomeScreen(state: AppState, onStart: () -> Unit) {
    val p = state.profile
    val today = LocalDate.now()
    val steps = remember(p) { buildPlan(p, 5, today.dayOfYear) }
    val week = state.workoutsThisWeek()
    val streak = state.streak()
    val doneToday = state.minutesOn(state.today()) > 0

    ScreenColumn {
        Title(if (p.name.isBlank()) "Hello!" else "Hello, ${p.name}!")
        AppCard {
            Text("Today's workout", style = MaterialTheme.typography.titleLarge)
            Text(
                "${steps.size} exercises, about ${planMinutes(steps)} minutes",
                style = MaterialTheme.typography.bodyLarge
            )
            if (doneToday) {
                Text("You have already moved today. Well done!", style = MaterialTheme.typography.bodyLarge)
            }
            BigButton(if (doneToday) "Do another workout" else "Start today's workout", onStart)
        }
        AppCard {
            Text("This week", style = MaterialTheme.typography.titleLarge)
            LinearProgressIndicator(
                progress = { (week.toFloat() / p.weeklyTarget).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(12.dp),
                trackColor = MaterialTheme.colorScheme.background
            )
            Text("$week of ${p.weeklyTarget} workouts in the last 7 days", style = MaterialTheme.typography.bodyLarge)
            Text(
                if (streak == 0) "Start a streak today." else "Streak: $streak day${if (streak == 1) "" else "s"}",
                style = MaterialTheme.typography.bodyLarge
            )
        }
        AppCard {
            Text("Tip", style = MaterialTheme.typography.titleMedium)
            Text(TIPS[today.dayOfYear % TIPS.size], style = MaterialTheme.typography.bodyLarge)
        }
    }
}

/* ------------------------------------------------------------------- Workout */

@Composable
fun WorkoutScreen(state: AppState, speaker: Speaker, onRunningChange: (Boolean) -> Unit) {
    var lengthIdx by remember { mutableIntStateOf(1) }
    var running by remember { mutableStateOf<List<Segment>?>(null) }
    var result by remember { mutableStateOf<Session?>(null) }
    val counts = listOf(3, 5, 8)
    val lengthLabels = listOf("Quick", "Standard", "Long")
    val steps = remember(state.profile, lengthIdx) {
        buildPlan(state.profile, counts[lengthIdx], LocalDate.now().dayOfYear)
    }

    LaunchedEffect(running != null) { onRunningChange(running != null) }
    DisposableEffect(Unit) { onDispose { onRunningChange(false) } }

    val segs = running
    val res = result
    if (segs != null) {
        WorkoutRunner(segs, state.settings, speaker) { elapsed, done ->
            running = null
            if (done >= 1) {
                val s = Session(state.today(), maxOf(1, (elapsed + 30) / 60), done, "Adaptive workout")
                state.addSession(s)
                result = s
            }
        }
    } else if (res != null) {
        val context = LocalContext.current
        LaunchedEffect(Unit) {
            if (state.settings.voice) speaker.say("Workout complete. Well done!")
            if (state.settings.haptics) buzz(context, 200L)
        }
        ScreenColumn {
            Title("Great job!")
            AppCard {
                Text("Workout saved", style = MaterialTheme.typography.titleLarge)
                Text("${res.exercises} exercises", style = MaterialTheme.typography.bodyLarge)
                Text("${res.minutes} minutes", style = MaterialTheme.typography.bodyLarge)
            }
            Text("Take a drink of water and rest. You earned it.", style = MaterialTheme.typography.bodyLarge)
            BigButton("Done", { result = null })
        }
    } else {
        ScreenColumn {
            Title("Your workout")
            Text("Built for your abilities, equipment and goals.", style = MaterialTheme.typography.bodyLarge)
            Text("How long?", style = MaterialTheme.typography.titleMedium)
            SingleSelect(
                items = listOf(0, 1, 2),
                selected = lengthIdx,
                label = { lengthLabels[it] },
                onSelect = { lengthIdx = it }
            )
            AppCard {
                Text(
                    "${steps.size} exercises, about ${planMinutes(steps)} minutes",
                    style = MaterialTheme.typography.titleMedium
                )
                steps.forEachIndexed { i, s ->
                    Text("${i + 1}. ${s.exercise.name} (${s.workSeconds} sec)", style = MaterialTheme.typography.bodyLarge)
                }
            }
            BigButton("Start workout", { running = toSegments(steps) })
            Text(
                "You can pause, skip or stop at any time. Stop if anything hurts.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun WorkoutRunner(
    segs: List<Segment>,
    settings: Settings,
    speaker: Speaker,
    onEnd: (Int, Int) -> Unit
) {
    val context = LocalContext.current
    val view = LocalView.current
    var index by remember { mutableIntStateOf(0) }
    var paused by remember { mutableStateOf(false) }
    var remaining by remember { mutableIntStateOf(segs[0].seconds) }
    var elapsed by remember { mutableIntStateOf(0) }
    val seg = segs[index]

    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose {
            view.keepScreenOn = false
            speaker.stop()
        }
    }

    val advance: () -> Unit = {
        if (index >= segs.lastIndex) {
            onEnd(elapsed, segs.count { !it.rest })
        } else {
            index += 1
            remaining = segs[index].seconds
        }
    }

    BackHandler { onEnd(elapsed, segs.take(index).count { !it.rest }) }

    LaunchedEffect(index) {
        val s = segs[index]
        if (settings.voice) {
            speaker.say(if (s.rest) "Rest. ${s.text}" else "${s.title}. ${s.text}")
        }
        if (settings.haptics) buzz(context)
    }

    LaunchedEffect(index, paused) {
        while (!paused) {
            if (remaining <= 0) {
                advance()
                break
            }
            delay(1000L)
            remaining -= 1
            elapsed += 1
        }
    }

    val target = (remaining.toFloat() / seg.seconds.toFloat()).coerceIn(0f, 1f)
    val progress = if (settings.reduceMotion) {
        target
    } else {
        animateFloatAsState(
            targetValue = target,
            animationSpec = tween(durationMillis = 1000, easing = LinearEasing),
            label = "countdown"
        ).value
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            if (seg.rest) "Rest" else "Exercise ${seg.stepNo} of ${seg.total}",
            style = MaterialTheme.typography.titleMedium
        )
        Text(
            seg.title,
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Text(seg.text, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
        Text("$remaining", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)
        Text("seconds left", style = MaterialTheme.typography.bodyMedium)
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(12.dp),
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
        BigButton(if (paused) "Resume" else "Pause", { paused = !paused })
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(
                onClick = { advance() },
                modifier = Modifier.weight(1f).heightIn(min = 56.dp)
            ) { Text("Skip") }
            OutlinedButton(
                onClick = { remaining += 15 },
                modifier = Modifier.weight(1f).heightIn(min = 56.dp)
            ) { Text("+15 sec") }
        }
        BigButton(
            "Stop workout",
            { onEnd(elapsed, segs.take(index).count { !it.rest }) },
            primary = false
        )
    }
}

/* ------------------------------------------------------------------ Progress */

@Composable
fun ProgressScreen(state: AppState) {
    val today = state.today()
    val days = (6 downTo 0).map { today - it }
    val mins = days.map { state.minutesOn(it) }
    val maxMin = maxOf(mins.maxOrNull() ?: 0, 10)
    val totalMin = state.history.sumOf { it.minutes }
    val streak = state.streak()
    val dateFmt = DateTimeFormatter.ofPattern("d MMM yyyy")

    ScreenColumn {
        Title("Your progress")
        AppCard {
            Text("Totals", style = MaterialTheme.typography.titleLarge)
            Text("Workouts: ${state.history.size}", style = MaterialTheme.typography.bodyLarge)
            Text("Active minutes: $totalMin", style = MaterialTheme.typography.bodyLarge)
            Text("Current streak: $streak day${if (streak == 1) "" else "s"}", style = MaterialTheme.typography.bodyLarge)
        }
        AppCard {
            Text("Last 7 days (minutes)", style = MaterialTheme.typography.titleLarge)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                days.forEachIndexed { i, d ->
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        Text("${mins[i]}", style = MaterialTheme.typography.bodySmall)
                        Box(
                            modifier = Modifier
                                .width(24.dp)
                                .height((90f * mins[i] / maxMin.toFloat()).dp + 4.dp)
                                .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp))
                        )
                        Text(
                            LocalDate.ofEpochDay(d).dayOfWeek.getDisplayName(
                                java.time.format.TextStyle.SHORT,
                                Locale.getDefault()
                            ),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
        Text("Recent workouts", style = MaterialTheme.typography.titleLarge)
        if (state.history.isEmpty()) {
            Text("No workouts yet. Your first one will show up here.", style = MaterialTheme.typography.bodyLarge)
        }
        state.history.takeLast(20).reversed().forEach { s ->
            AppCard {
                Text(LocalDate.ofEpochDay(s.day).format(dateFmt), style = MaterialTheme.typography.titleMedium)
                Text("${s.exercises} exercises, ${s.minutes} min", style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

/* ------------------------------------------------------------------- Profile */

@Composable
fun ProfileScreen(state: AppState) {
    val p = state.profile
    val metric = state.settings.metric
    var name by remember { mutableStateOf(p.name) }
    var ageText by remember { mutableStateOf(if (p.age > 0) p.age.toString() else "") }
    var heightText by remember(metric) {
        mutableStateOf(if (p.heightCm > 0f) fmt(if (metric) p.heightCm else p.heightCm / 2.54f) else "")
    }
    var weightText by remember(metric) {
        mutableStateOf(if (p.weightKg > 0f) fmt(if (metric) p.weightKg else p.weightKg / 0.45359237f) else "")
    }
    var mobility by remember { mutableStateOf(p.mobility) }
    var limitations by remember { mutableStateOf(p.limitations) }
    var equipment by remember { mutableStateOf(p.equipment) }
    var goals by remember { mutableStateOf(p.goals) }
    var target by remember { mutableIntStateOf(p.weeklyTarget) }
    var message by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    ScreenColumn {
        Title("Your profile")
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = ageText,
            onValueChange = { ageText = it },
            label = { Text("Age (optional)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = heightText,
            onValueChange = { heightText = it },
            label = { Text(if (metric) "Height in cm (optional)" else "Height in inches (optional)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = weightText,
            onValueChange = { weightText = it },
            label = { Text(if (metric) "Weight in kg (optional)" else "Weight in lb (optional)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )

        Text("How you move", style = MaterialTheme.typography.titleLarge)
        SingleSelect(
            items = Mobility.values().toList(),
            selected = mobility,
            label = { it.label },
            help = { it.help },
            onSelect = { mobility = it }
        )
        Text("Things to work around", style = MaterialTheme.typography.titleLarge)
        MultiSelect(
            items = Limitation.values().toList(),
            selected = limitations,
            label = { it.label },
            onChange = { limitations = it }
        )
        Text("Equipment", style = MaterialTheme.typography.titleLarge)
        MultiSelect(
            items = Equipment.values().toList(),
            selected = equipment,
            label = { it.label },
            onChange = { equipment = it }
        )
        Text("Goals", style = MaterialTheme.typography.titleLarge)
        MultiSelect(
            items = Goal.values().toList(),
            selected = goals,
            label = { it.label },
            onChange = { goals = it }
        )
        Text("Weekly target", style = MaterialTheme.typography.titleLarge)
        SingleSelect(
            items = listOf(2, 3, 4, 5),
            selected = target,
            label = { "$it days a week" },
            onSelect = { target = it }
        )

        val msg = message
        if (msg != null) {
            Text(
                msg,
                style = MaterialTheme.typography.titleMedium,
                color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
            )
        }
        BigButton("Save profile", {
            var err: String? = null
            val ageV = if (ageText.isBlank()) 0 else (ageText.trim().toIntOrNull() ?: -1)
            if (ageV != 0 && ageV !in 5..110) err = "Please enter an age between 5 and 110."
            val hv = if (heightText.isBlank()) 0f else (parseNum(heightText) ?: -1f)
            val hCm = if (metric) hv else hv * 2.54f
            if (err == null && hv != 0f && (hCm < 50f || hCm > 250f)) {
                err = "Please check your height. It looks outside the usual range."
            }
            val wv = if (weightText.isBlank()) 0f else (parseNum(weightText) ?: -1f)
            val wKg = if (metric) wv else wv * 0.45359237f
            if (err == null && wv != 0f && (wKg < 20f || wKg > 350f)) {
                err = "Please check your weight. It looks outside the usual range."
            }
            if (err == null && goals.isEmpty()) err = "Please pick at least one goal."
            if (err != null) {
                isError = true
                message = err
            } else {
                state.saveProfile(
                    p.copy(
                        name = name.trim(),
                        age = ageV,
                        heightCm = if (hv == 0f) 0f else hCm,
                        weightKg = if (wv == 0f) 0f else wKg,
                        mobility = mobility,
                        limitations = limitations,
                        equipment = equipment,
                        goals = goals,
                        weeklyTarget = target
                    )
                )
                isError = false
                message = "Saved. Your workouts now match these details."
            }
        })
    }
}

/* ------------------------------------------------------------------ Settings */

@Composable
fun SettingsScreen(state: AppState) {
    val s = state.settings
    var confirmReset by remember { mutableStateOf(false) }

    ScreenColumn {
        Title("Settings")
        AppCard {
            Text("Text size", style = MaterialTheme.typography.titleLarge)
            SingleSelect(
                items = listOf(0, 1, 2),
                selected = s.textSize,
                label = { listOf("Normal", "Large", "Extra large")[it] },
                onSelect = { state.saveSettings(s.copy(textSize = it)) }
            )
        }
        AppCard {
            Text("Display", style = MaterialTheme.typography.titleLarge)
            SwitchRow("High contrast", "Stronger colours that are easier to see", s.highContrast) {
                state.saveSettings(s.copy(highContrast = it))
            }
            SwitchRow("Reduce motion", "Turn off moving progress bars", s.reduceMotion) {
                state.saveSettings(s.copy(reduceMotion = it))
            }
        }
        AppCard {
            Text("During workouts", style = MaterialTheme.typography.titleLarge)
            SwitchRow("Voice guidance", "Read each exercise out loud", s.voice) {
                state.saveSettings(s.copy(voice = it))
            }
            SwitchRow("Vibration", "A short buzz when the exercise changes", s.haptics) {
                state.saveSettings(s.copy(haptics = it))
            }
        }
        AppCard {
            Text("Units", style = MaterialTheme.typography.titleLarge)
            SingleSelect(
                items = listOf(true, false),
                selected = s.metric,
                label = { if (it) "Metric (kg, cm)" else "Imperial (lb, in)" },
                onSelect = { state.saveSettings(s.copy(metric = it)) }
            )
        }
        AppCard {
            Text("Theme", style = MaterialTheme.typography.titleLarge)
            SingleSelect(
                items = listOf(0, 1, 2),
                selected = s.theme,
                label = { listOf("Match my phone", "Light", "Dark")[it] },
                onSelect = { state.saveSettings(s.copy(theme = it)) }
            )
        }
        Text(
            "All your information stays on this phone. AdaptFit never sends it anywhere.",
            style = MaterialTheme.typography.bodyMedium
        )
        BigButton("Delete all my data", { confirmReset = true }, primary = false)
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Delete everything?") },
            text = { Text("This removes your profile, settings and workout history from this phone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    state.resetAll()
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Cancel") }
            }
        )
    }
}
