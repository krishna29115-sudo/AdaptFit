package com.adaptfit.app

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

private inline fun <reified T : Enum<T>> parseSet(s: String?): Set<T> =
    (s ?: "").split(",")
        .filter { it.isNotBlank() }
        .mapNotNull { n -> enumValues<T>().firstOrNull { it.name == n } }
        .toSet()

class AppState(private val prefs: SharedPreferences) {

    var profile by mutableStateOf(readProfile())
        private set
    var settings by mutableStateOf(readSettings())
        private set
    var history by mutableStateOf(readHistory())
        private set

    private fun readProfile(): Profile {
        val mobilityName = prefs.getString("mobility", "") ?: ""
        val goals = parseSet<Goal>(prefs.getString("goals", ""))
        return Profile(
            name = prefs.getString("name", "") ?: "",
            age = prefs.getInt("age", 0),
            heightCm = prefs.getFloat("heightCm", 0f),
            weightKg = prefs.getFloat("weightKg", 0f),
            mobility = Mobility.values().firstOrNull { it.name == mobilityName } ?: Mobility.SEATED,
            limitations = parseSet<Limitation>(prefs.getString("limitations", "")),
            equipment = parseSet<Equipment>(prefs.getString("equipment", "")),
            goals = if (goals.isEmpty()) setOf(Goal.MOBILITY) else goals,
            weeklyTarget = prefs.getInt("weeklyTarget", 3),
            onboarded = prefs.getBoolean("onboarded", false)
        )
    }

    private fun readSettings(): Settings = Settings(
        textSize = prefs.getInt("textSize", 0),
        highContrast = prefs.getBoolean("highContrast", false),
        reduceMotion = prefs.getBoolean("reduceMotion", false),
        voice = prefs.getBoolean("voice", false),
        haptics = prefs.getBoolean("haptics", true),
        metric = prefs.getBoolean("metric", true),
        theme = prefs.getInt("theme", 0)
    )

    private fun readHistory(): List<Session> {
        val raw = prefs.getString("history", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Session(o.getLong("day"), o.getInt("minutes"), o.getInt("exercises"), o.getString("title"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveProfile(p: Profile) {
        profile = p
        prefs.edit()
            .putString("name", p.name)
            .putInt("age", p.age)
            .putFloat("heightCm", p.heightCm)
            .putFloat("weightKg", p.weightKg)
            .putString("mobility", p.mobility.name)
            .putString("limitations", p.limitations.joinToString(",") { it.name })
            .putString("equipment", p.equipment.joinToString(",") { it.name })
            .putString("goals", p.goals.joinToString(",") { it.name })
            .putInt("weeklyTarget", p.weeklyTarget)
            .putBoolean("onboarded", p.onboarded)
            .apply()
    }

    fun saveSettings(s: Settings) {
        settings = s
        prefs.edit()
            .putInt("textSize", s.textSize)
            .putBoolean("highContrast", s.highContrast)
            .putBoolean("reduceMotion", s.reduceMotion)
            .putBoolean("voice", s.voice)
            .putBoolean("haptics", s.haptics)
            .putBoolean("metric", s.metric)
            .putInt("theme", s.theme)
            .apply()
    }

    fun addSession(s: Session) {
        history = (history + s).takeLast(500)
        val arr = JSONArray()
        history.forEach {
            val o = JSONObject()
            o.put("day", it.day)
            o.put("minutes", it.minutes)
            o.put("exercises", it.exercises)
            o.put("title", it.title)
            arr.put(o)
        }
        prefs.edit().putString("history", arr.toString()).apply()
    }

    fun resetAll() {
        prefs.edit().clear().apply()
        profile = Profile()
        settings = Settings()
        history = emptyList()
    }

    fun today(): Long = LocalDate.now().toEpochDay()

    fun streak(): Int {
        val days = history.map { it.day }.toSet()
        var d = today()
        if (d !in days) d -= 1
        var n = 0
        while (d in days) {
            n++
            d--
        }
        return n
    }

    fun workoutsThisWeek(): Int = history.count { it.day > today() - 7 }

    fun minutesOn(day: Long): Int = history.filter { it.day == day }.sumOf { it.minutes }
}
