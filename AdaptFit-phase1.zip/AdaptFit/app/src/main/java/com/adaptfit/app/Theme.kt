package com.adaptfit.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density

private val LightScheme = lightColorScheme(
    primary = Color(0xFF0F766E), onPrimary = Color.White,
    primaryContainer = Color(0xFFCCEFEA), onPrimaryContainer = Color(0xFF00201D),
    secondaryContainer = Color(0xFFBFE6E0), onSecondaryContainer = Color(0xFF0B1F1D),
    background = Color(0xFFF7FAF9), onBackground = Color(0xFF151A19),
    surface = Color(0xFFF7FAF9), onSurface = Color(0xFF151A19),
    surfaceVariant = Color(0xFFDDE8E5), onSurfaceVariant = Color(0xFF1F2B29),
    outline = Color(0xFF59706C), error = Color(0xFFB3261E)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF5EEAD4), onPrimary = Color(0xFF00382F),
    primaryContainer = Color(0xFF005047), onPrimaryContainer = Color(0xFFB2F5EA),
    secondaryContainer = Color(0xFF204A44), onSecondaryContainer = Color(0xFFD6F5F0),
    background = Color(0xFF101414), onBackground = Color(0xFFE0E4E2),
    surface = Color(0xFF101414), onSurface = Color(0xFFE0E4E2),
    surfaceVariant = Color(0xFF2B3533), onSurfaceVariant = Color(0xFFDCE5E2),
    outline = Color(0xFF8AA19C), error = Color(0xFFFFB4AB)
)

private val HighContrastLight = lightColorScheme(
    primary = Color(0xFF002B9A), onPrimary = Color.White,
    primaryContainer = Color.White, onPrimaryContainer = Color.Black,
    secondaryContainer = Color(0xFFFFE066), onSecondaryContainer = Color.Black,
    background = Color.White, onBackground = Color.Black,
    surface = Color.White, onSurface = Color.Black,
    surfaceVariant = Color(0xFFEDEDED), onSurfaceVariant = Color.Black,
    outline = Color.Black, error = Color(0xFF8C0000)
)

private val HighContrastDark = darkColorScheme(
    primary = Color(0xFFFFE066), onPrimary = Color.Black,
    primaryContainer = Color.Black, onPrimaryContainer = Color.White,
    secondaryContainer = Color(0xFF5C4B00), onSecondaryContainer = Color.White,
    background = Color.Black, onBackground = Color.White,
    surface = Color.Black, onSurface = Color.White,
    surfaceVariant = Color(0xFF222222), onSurfaceVariant = Color.White,
    outline = Color.White, error = Color(0xFFFF8A80)
)

@Composable
fun AdaptFitTheme(settings: Settings, content: @Composable () -> Unit) {
    val dark = when (settings.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val scheme = if (settings.highContrast) {
        if (dark) HighContrastDark else HighContrastLight
    } else {
        if (dark) DarkScheme else LightScheme
    }
    val base = LocalDensity.current
    val scale = when (settings.textSize) {
        1 -> 1.25f
        2 -> 1.5f
        else -> 1f
    }
    CompositionLocalProvider(LocalDensity provides Density(base.density, base.fontScale * scale)) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
