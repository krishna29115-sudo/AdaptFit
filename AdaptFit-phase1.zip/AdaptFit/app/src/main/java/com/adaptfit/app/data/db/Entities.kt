package com.adaptfit.app.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Single-row profile. Body values are always stored metric (cm, kg). */
@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "",
    val age: Int = 0,
    val sex: String = "Prefer not to say",
    val heightCm: Float = 0f,
    val weightKg: Float = 0f,
    val onboardingDone: Boolean = false
)
