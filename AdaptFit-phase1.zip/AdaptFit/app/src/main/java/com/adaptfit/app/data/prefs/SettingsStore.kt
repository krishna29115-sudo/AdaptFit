package com.adaptfit.app.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

data class AppSettings(
    val fontScale: Float = 1.0f,
    val highContrast: Boolean = false,
    val reduceMotion: Boolean = false,
    val voiceGuidance: Boolean = false,
    val haptics: Boolean = true,
    val metric: Boolean = true,
    val theme: String = "system" // system | light | dark
)

private val Context.dataStore by preferencesDataStore(name = "settings")

class SettingsStore(private val context: Context) {
    private val FONT = floatPreferencesKey("font_scale")
    private val HC = booleanPreferencesKey("high_contrast")
    private val MOTION = booleanPreferencesKey("reduce_motion")
    private val VOICE = booleanPreferencesKey("voice")
    private val HAPTIC = booleanPreferencesKey("haptics")
    private val METRIC = booleanPreferencesKey("metric")
    private val THEME = stringPreferencesKey("theme")

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            fontScale = p[FONT] ?: 1.0f,
            highContrast = p[HC] ?: false,
            reduceMotion = p[MOTION] ?: false,
            voiceGuidance = p[VOICE] ?: false,
            haptics = p[HAPTIC] ?: true,
            metric = p[METRIC] ?: true,
            theme = p[THEME] ?: "system"
        )
    }

    suspend fun update(s: AppSettings) {
        context.dataStore.edit { p ->
            p[FONT] = s.fontScale; p[HC] = s.highContrast; p[MOTION] = s.reduceMotion
            p[VOICE] = s.voiceGuidance; p[HAPTIC] = s.haptics; p[METRIC] = s.metric; p[THEME] = s.theme
        }
    }
}
