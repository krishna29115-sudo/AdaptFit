package com.adaptfit.app.data.repo

import com.adaptfit.app.data.db.ProfileDao
import com.adaptfit.app.data.db.UserProfileEntity
import kotlinx.coroutines.flow.Flow

class ProfileRepository(private val dao: ProfileDao) {
    val profile: Flow<UserProfileEntity?> = dao.observe()
    suspend fun save(p: UserProfileEntity) = dao.upsert(p)
}
