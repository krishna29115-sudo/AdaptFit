package com.adaptfit.app.ui.nav

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.adaptfit.app.AppContainer
import com.adaptfit.app.ui.profile.ProfileScreen
import com.adaptfit.app.ui.settings.AccessibilitySettingsScreen

enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Home", Icons.Filled.Home),
    Workouts("workouts", "Workouts", Icons.Filled.FitnessCenter),
    Nutrition("nutrition", "Nutrition", Icons.Filled.Restaurant),
    Progress("progress", "Progress", Icons.Filled.BarChart),
    Profile("profile", "Profile", Icons.Filled.Person)
}

private const val SETTINGS = "settings"

@Composable
fun AdaptFitNav(container: AppContainer) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    Scaffold(
        bottomBar = {
            if (route != SETTINGS) NavigationBar {
                Tab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route,
                        onClick = {
                            nav.navigate(t.route) {
                                popUpTo(Tab.Home.route) { saveState = true }
                                launchSingleTop = true; restoreState = true
                            }
                        },
                        icon = { Icon(t.icon, contentDescription = null) },
                        label = { Text(t.label) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = Tab.Home.route, modifier = Modifier.padding(pad)) {
            composable(Tab.Home.route) { Pending("Home", "Phase 2") }
            composable(Tab.Workouts.route) { Pending("Workouts", "Phase 3") }
            composable(Tab.Nutrition.route) { Pending("Nutrition", "Phase 4") }
            composable(Tab.Progress.route) { Pending("Progress", "Phase 5") }
            composable(Tab.Profile.route) { ProfileScreen(container, onOpenSettings = { nav.navigate(SETTINGS) }) }
            composable(SETTINGS) { AccessibilitySettingsScreen(container.settings, onBack = { nav.popBackStack() }) }
        }
    }
}

/** Honest marker for tabs not built yet; replaced phase by phase. */
@Composable
private fun Pending(title: String, phase: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text("$title is not built yet. Planned for $phase.", style = MaterialTheme.typography.titleMedium)
    }
}
