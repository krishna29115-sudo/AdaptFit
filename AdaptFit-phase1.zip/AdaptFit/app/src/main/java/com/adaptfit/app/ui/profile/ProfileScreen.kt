package com.adaptfit.app.ui.profile

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.adaptfit.app.AppContainer
import com.adaptfit.app.VMFactory
import com.adaptfit.app.data.prefs.AppSettings
import com.adaptfit.app.util.Units
import java.util.Locale

private val SEX_OPTIONS = listOf("Female", "Male", "Other", "Prefer not to say")

@Composable
fun ProfileScreen(container: AppContainer, onOpenSettings: () -> Unit) {
    val vm: ProfileViewModel = viewModel(factory = VMFactory(container))
    val profile by vm.profile.collectAsStateWithLifecycle()
    val settings by container.settings.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
    val metric = settings.metric

    var name by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var sex by remember { mutableStateOf(SEX_OPTIONS.last()) }
    var height by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    // Prefill from the database, and re-convert when the unit system changes.
    LaunchedEffect(profile, metric) {
        profile?.let { p ->
            name = p.name
            age = if (p.age > 0) p.age.toString() else ""
            sex = p.sex
            height = if (p.heightCm > 0) fmt(if (metric) p.heightCm else Units.cmToIn(p.heightCm)) else ""
            weight = if (p.weightKg > 0) fmt(if (metric) p.weightKg else Units.kgToLb(p.weightKg)) else ""
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Profile", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(name, { name = it }, label = { Text("Name") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(age, { age = it.filter(Char::isDigit).take(3) }, label = { Text("Age") },
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth())

        Text("Sex (used only for calorie estimates)", style = MaterialTheme.typography.titleMedium)
        Column(Modifier.fillMaxWidth()) {
            SEX_OPTIONS.forEach { opt ->
                Row(Modifier.fillMaxWidth().heightIn(min = 56.dp)
                    .selectable(selected = sex == opt, onClick = { sex = opt }, role = Role.RadioButton),
                    verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = sex == opt, onClick = null)
                    Spacer(Modifier.width(12.dp))
                    Text(opt, style = MaterialTheme.typography.bodyLarge)
                }
            }
        }

        OutlinedTextField(height, { height = it.filter { c -> c.isDigit() || c == '.' }.take(6) },
            label = { Text(if (metric) "Height (cm)" else "Height (inches)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(weight, { weight = it.filter { c -> c.isDigit() || c == '.' }.take(6) },
            label = { Text(if (metric) "Weight (kg)" else "Weight (lb)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())

        message?.let {
            // Text prefix means the status never depends on color alone.
            Text(if (isError) "Problem: $it" else it,
                color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.bodyLarge)
        }
        Button(onClick = {
            vm.save(name, age, sex, height, weight, metric) { err ->
                isError = err != null; message = err ?: "Saved."
            }
        }, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Save profile") }
        OutlinedButton(onClick = onOpenSettings, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) {
            Text("Accessibility and display settings")
        }
    }
}

private fun fmt(v: Float) = String.format(Locale.US, "%.1f", v)
