package com.adaptfit.app.ui.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adaptfit.app.data.db.UserProfileEntity
import com.adaptfit.app.data.repo.ProfileRepository
import com.adaptfit.app.util.Units
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ProfileViewModel(private val repo: ProfileRepository) : ViewModel() {
    val profile: StateFlow<UserProfileEntity?> =
        repo.profile.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    /** Validates text input; calls [onResult] with an error message, or null on success. */
    fun save(name: String, age: String, sex: String, height: String, weight: String,
             metric: Boolean, onResult: (String?) -> Unit) {
        val a = age.trim().toIntOrNull()
        val h = height.trim().toFloatOrNull()
        val w = weight.trim().toFloatOrNull()
        val error = when {
            name.isBlank() -> "Please enter a name."
            a == null || a !in 13..110 -> "Please enter an age between 13 and 110."
            h == null || h <= 0f -> "Please enter a valid height."
            w == null || w <= 0f -> "Please enter a valid weight."
            else -> null
        }
        if (error != null || a == null || h == null || w == null) { onResult(error); return }
        val cm = if (metric) h else Units.inToCm(h)
        val kg = if (metric) w else Units.lbToKg(w)
        if (cm !in 90f..250f) { onResult("Height looks out of range. Please check it."); return }
        if (kg !in 20f..350f) { onResult("Weight looks out of range. Please check it."); return }
        viewModelScope.launch {
            try {
                val old = profile.value
                repo.save(UserProfileEntity(1, name.trim(), a, sex, cm, kg, old?.onboardingDone ?: false))
                onResult(null)
            } catch (e: Exception) {
                onResult("Could not save. Please try again.")
            }
        }
    }
}
