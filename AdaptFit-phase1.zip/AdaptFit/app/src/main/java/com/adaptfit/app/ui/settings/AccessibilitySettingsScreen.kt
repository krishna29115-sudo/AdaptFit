package com.adaptfit.app.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.adaptfit.app.data.prefs.AppSettings
import com.adaptfit.app.data.prefs.SettingsStore
import kotlinx.coroutines.launch

private val SCALES = listOf(0.85f, 1.0f, 1.15f, 1.3f, 1.5f)

@Composable
fun AccessibilitySettingsScreen(store: SettingsStore, onBack: () -> Unit) {
    val s by store.settings.collectAsStateWithLifecycle(initialValue = AppSettings())
    val scope = rememberCoroutineScope()
    fun change(n: AppSettings) { scope.launch { store.update(n) } }
    val idx = SCALES.indexOfFirst { it >= s.fontScale - 0.001f }.coerceAtLeast(0)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack, modifier = Modifier.heightIn(min = 48.dp)) { Text("Back") }
        Text("Accessibility and display", style = MaterialTheme.typography.headlineMedium)

        Text("Text size: ${(s.fontScale * 100).toInt()}%", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { change(s.copy(fontScale = SCALES[(idx - 1).coerceAtLeast(0)])) },
                enabled = idx > 0, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) { Text("Smaller") }
            Button(onClick = { change(s.copy(fontScale = SCALES[(idx + 1).coerceAtMost(SCALES.lastIndex)])) },
                enabled = idx < SCALES.lastIndex, modifier = Modifier.weight(1f).heightIn(min = 56.dp)) { Text("Larger") }
        }

        SwitchRow("High contrast", "Stronger colors and borders", s.highContrast) { change(s.copy(highContrast = it)) }
        SwitchRow("Reduce animation", "Fewer moving elements", s.reduceMotion) { change(s.copy(reduceMotion = it)) }
        SwitchRow("Voice guidance", "Spoken workout cues, always with text too", s.voiceGuidance) { change(s.copy(voiceGuidance = it)) }
        SwitchRow("Haptic feedback", "Vibration on key actions", s.haptics) { change(s.copy(haptics = it)) }

        Text("Units", style = MaterialTheme.typography.titleMedium)
        RadioRow("Metric (kg, cm)", s.metric) { change(s.copy(metric = true)) }
        RadioRow("Imperial (lb, in)", !s.metric) { change(s.copy(metric = false)) }

        Text("Theme", style = MaterialTheme.typography.titleMedium)
        listOf("system" to "Follow device", "light" to "Light", "dark" to "Dark").forEach { (k, label) ->
            RadioRow(label, s.theme == k) { change(s.copy(theme = k)) }
        }
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp)
        .toggleable(value = checked, role = Role.Switch, onValueChange = onChange),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium)
        }
        Switch(checked = checked, onCheckedChange = null)
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp)
        .selectable(selected = selected, onClick = onClick, role = Role.RadioButton),
        verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
