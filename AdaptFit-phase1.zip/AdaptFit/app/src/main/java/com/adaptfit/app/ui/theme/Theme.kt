package com.adaptfit.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import com.adaptfit.app.data.prefs.AppSettings

private val LightScheme = lightColorScheme(
    primary = Color(0xFF0B6E69), onPrimary = Color.White,
    primaryContainer = Color(0xFFCDEEEA), onPrimaryContainer = Color(0xFF00201E),
    background = Color(0xFFF7FAF9), surface = Color(0xFFF7FAF9), onSurface = Color(0xFF111413)
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF7FD8D1), onPrimary = Color(0xFF00201E),
    primaryContainer = Color(0xFF00504C), onPrimaryContainer = Color(0xFFCDEEEA),
    background = Color(0xFF0F1413), surface = Color(0xFF0F1413), onSurface = Color(0xFFE6EAE9)
)
private val HighContrastLight = lightColorScheme(
    primary = Color(0xFF00403C), onPrimary = Color.White,
    primaryContainer = Color.White, onPrimaryContainer = Color.Black,
    background = Color.White, onBackground = Color.Black, surface = Color.White, onSurface = Color.Black,
    surfaceVariant = Color.White, onSurfaceVariant = Color.Black, outline = Color.Black,
    secondaryContainer = Color(0xFFFFE600), onSecondaryContainer = Color.Black
)
private val HighContrastDark = darkColorScheme(
    primary = Color(0xFFFFE600), onPrimary = Color.Black,
    primaryContainer = Color.Black, onPrimaryContainer = Color.White,
    background = Color.Black, onBackground = Color.White, surface = Color.Black, onSurface = Color.White,
    surfaceVariant = Color.Black, onSurfaceVariant = Color.White, outline = Color.White,
    secondaryContainer = Color(0xFFFFE600), onSecondaryContainer = Color.Black
)

@Composable
fun AdaptFitTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val scheme = when {
        settings.highContrast && dark -> HighContrastDark
        settings.highContrast -> HighContrastLight
        dark -> DarkScheme
        else -> LightScheme
    }
    // User scale multiplies the system font scale, so both are respected.
    val base = LocalDensity.current
    val density = Density(base.density, base.fontScale * settings.fontScale)
    CompositionLocalProvider(LocalDensity provides density) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
