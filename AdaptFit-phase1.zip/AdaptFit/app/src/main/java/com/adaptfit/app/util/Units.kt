package com.adaptfit.app.util

object Units {
    private const val CM_PER_IN = 2.54f
    private const val LB_PER_KG = 2.2046226f
    fun cmToIn(cm: Float) = cm / CM_PER_IN
    fun inToCm(i: Float) = i * CM_PER_IN
    fun kgToLb(kg: Float) = kg * LB_PER_KG
    fun lbToKg(lb: Float) = lb / LB_PER_KG
}
