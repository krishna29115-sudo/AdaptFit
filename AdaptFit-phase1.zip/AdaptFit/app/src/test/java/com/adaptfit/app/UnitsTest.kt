package com.adaptfit.app

import com.adaptfit.app.util.Units
import org.junit.Assert.assertEquals
import org.junit.Test

class UnitsTest {
    @Test fun kgLbRoundTrip() = assertEquals(70f, Units.lbToKg(Units.kgToLb(70f)), 0.01f)
    @Test fun cmInRoundTrip() = assertEquals(170f, Units.inToCm(Units.cmToIn(170f)), 0.01f)
}
