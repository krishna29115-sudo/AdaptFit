# Adapt Fit (Stage 1)

Native Android app, Java + XML only. No Kotlin, no Compose.

## Get your APK with GitHub (no coding needed)
1. Create a free account at github.com and sign in.
2. Tap the + (top right) > New repository. Name it AdaptFit. Choose Private. Create it.
3. Tap "uploading an existing file". Unzip this project on your computer and drag in ALL
   files and folders, including the hidden folder .github (it holds the build recipe).
   Tap Commit changes.
4. Open the Actions tab. Choose "Build APK". The build starts by itself; if not, tap Run workflow.
5. Wait about 5 to 8 minutes for a green tick. Open the finished run, scroll to Artifacts,
   download AdaptFit-debug-apk, unzip it to get app-debug.apk.
6. Copy app-debug.apk to your phone, open it, and allow "Install unknown apps" when asked.

If the run shows a red cross, open it, copy the error text and send it to Claude to fix.

## Status
Built and checked only by reading the code. It has NOT been compiled or run yet.
See the project chat for what is done and what is planned.
