package com.adaptfit.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.adaptfit.app.data.ProfileStore;

public class HomeActivity extends AppCompatActivity {
    private ProfileStore store;
    private TextView greeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        store = new ProfileStore(this);
        greeting = findViewById(R.id.greeting);

        findViewById(R.id.btnWorkout).setOnClickListener(v -> comingSoon(getString(R.string.btn_workout)));
        findViewById(R.id.btnYoga).setOnClickListener(v -> comingSoon(getString(R.string.btn_yoga)));
        findViewById(R.id.btnNutrition).setOnClickListener(v -> comingSoon(getString(R.string.btn_nutrition)));
        findViewById(R.id.btnSara).setOnClickListener(v -> comingSoon(getString(R.string.btn_sara)));
        findViewById(R.id.btnSafety).setOnClickListener(v ->
                startActivity(new Intent(this, DisclaimerActivity.class)));
        findViewById(R.id.btnProfile).setOnClickListener(v ->
                startActivity(new Intent(this, ProfileActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!store.isOnboarded()) {
            startActivity(new Intent(this, OnboardingActivity.class));
            finish();
            return;
        }
        greeting.setText("Hello, " + store.getString(ProfileStore.NAME, "there") + "!");
    }

    private void comingSoon(String title) {
        Intent i = new Intent(this, ComingSoonActivity.class);
        i.putExtra(ComingSoonActivity.EXTRA_TITLE, title);
        startActivity(i);
    }
}
