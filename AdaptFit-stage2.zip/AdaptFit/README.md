# Adapt Fit (Stage 2)

Native Android app, Java + XML only. No Kotlin, no Compose.

## Get your APK with GitHub (no coding needed)
1. Create a free account at github.com and sign in.
2. Tap the + (top right) > New repository. Name it AdaptFit. Choose Private. Create it.
3. Tap "uploading an existing file". Unzip this project on your computer and drag in ALL
   files and folders, including the hidden folder .github (it holds the build recipe).
   Tap Commit changes.
4. Open the Actions tab. Choose "Build APK". The build starts by itself; if not, tap Run workflow.
5. Wait about 5 to 8 minutes for a green tick. Open the finished run, scroll to Artifacts,
   download AdaptFit-debug-apk, unzip it to get app-debug.apk.
6. Copy app-debug.apk to your phone, open it, and allow "Install unknown apps" when asked.

If the run shows a red cross, open it, copy the error text and send it to Claude to fix.

## What Stage 2 adds
- **Start Workout** and **Adaptive Yoga** on the Home screen now work.
- Each session is built from your profile: goal, activity level, adaptations (shoulder, grip,
  trunk control, reduced sensation, tires easily, very gentle), equipment and session length.
  Movements that do not suit your adaptations or equipment are left out.
- Everything is seated with the back supported, upper body only. Each exercise shows steps,
  a safety tip and an easier option.
- Guided session: big timer, pause, skip, stop, and an "I feel unwell - stop now" button that
  shows the safety advice and opens the phone dialler for 112.
- After a session you can rate it (too easy / just right / too hard). Two hard or easy
  sessions in a row make the next plan gentler or a little harder.
- Progress: last 7 days and your 5 most recent sessions.
- Workout history stays on the phone only and is deleted with "Delete all my data".
- Nutrition Centre and Ask Sara still show the "not built yet" screen (later stages).

## Status
The planning logic was tested on a computer (about 49,000 profile combinations).
The screens have NOT been compiled or run on a phone yet, so the first GitHub build is the first
real compile. If the run shows a red cross, copy the error text and send it to Claude.
