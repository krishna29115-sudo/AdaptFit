package com.adaptfit.app;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/** Honest placeholder shown for features that are built in later stages. */
public class ComingSoonActivity extends AppCompatActivity {
    public static final String EXTRA_TITLE = "title";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coming_soon);
        String title = getIntent().getStringExtra(EXTRA_TITLE);
        TextView t = findViewById(R.id.comingTitle);
        t.setText(title == null ? getString(R.string.app_name) : title + " - not built yet");
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
}
