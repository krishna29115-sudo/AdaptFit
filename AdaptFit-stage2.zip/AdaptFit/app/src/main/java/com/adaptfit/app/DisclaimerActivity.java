package com.adaptfit.app;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class DisclaimerActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disclaimer);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }
}
