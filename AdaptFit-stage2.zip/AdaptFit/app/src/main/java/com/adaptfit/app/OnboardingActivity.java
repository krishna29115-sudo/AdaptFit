package com.adaptfit.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.adaptfit.app.data.ProfileStore;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.radiobutton.MaterialRadioButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.HashSet;
import java.util.Set;

public class OnboardingActivity extends AppCompatActivity {
    private static final int STEPS = 5;
    private static final String KEY_STEP = "step";

    private static final String[] GOALS = {
            "General fitness", "Upper-body strength", "Flexibility and mobility",
            "Improving stamina", "Weight management", "Healthy eating",
            "Maintaining independence in daily activities", "Stress reduction and relaxation"};
    private static final String[] LEVELS = {
            "Just starting out", "Lightly active", "Moderately active", "Very active"};
    private static final String[] LOWER = {
            "Partial lower-body mobility", "Complete lower-body mobility loss",
            "Varies day to day", "Prefer not to say"};
    private static final String[] LIMITS = {
            "Limited shoulder mobility", "Limited hand grip", "Limited trunk control",
            "Reduced sensation", "Gets tired easily", "Prefer very gentle movement"};
    private static final String[] EQUIPMENT = {
            "No equipment", "Resistance band", "Light dumbbells",
            "Water bottles or household items", "Exercise ball", "Sturdy chair or table"};
    private static final String[] DURATIONS = {
            "5 minutes", "10 minutes", "15 minutes", "20 minutes or more"};
    private static final String[] DIETS = {
            "Vegetarian", "Non-vegetarian", "Vegan", "Eggetarian", "No preference"};
    private static final String[] UNITS = {"Metric (kg, cm)", "Imperial (lb, in)"};

    private int step = 0;
    private View[] stepViews;
    private TextView stepLabel;
    private LinearProgressIndicator progress;
    private com.google.android.material.button.MaterialButton btnPrev, btnNext;
    private ScrollView scroll;
    private TextInputEditText nameInput, ageInput, allergiesInput, healthInput;
    private RadioGroup goalGroup, levelGroup, lowerGroup, durationGroup, dietGroup, unitsGroup;
    private LinearLayout limitsBox, equipBox;
    private MaterialSwitch remindersSwitch;
    private MaterialCheckBox consentBox;
    private ProfileStore store;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);
        store = new ProfileStore(this);

        stepViews = new View[]{findViewById(R.id.step0), findViewById(R.id.step1),
                findViewById(R.id.step2), findViewById(R.id.step3), findViewById(R.id.step4)};
        stepLabel = findViewById(R.id.stepLabel);
        progress = findViewById(R.id.progress);
        scroll = findViewById(R.id.scroll);
        btnPrev = findViewById(R.id.btnPrev);
        btnNext = findViewById(R.id.btnNext);
        nameInput = findViewById(R.id.nameInput);
        ageInput = findViewById(R.id.ageInput);
        allergiesInput = findViewById(R.id.allergiesInput);
        healthInput = findViewById(R.id.healthInput);
        goalGroup = findViewById(R.id.goalGroup);
        levelGroup = findViewById(R.id.levelGroup);
        lowerGroup = findViewById(R.id.lowerGroup);
        durationGroup = findViewById(R.id.durationGroup);
        dietGroup = findViewById(R.id.dietGroup);
        unitsGroup = findViewById(R.id.unitsGroup);
        limitsBox = findViewById(R.id.limitsBox);
        equipBox = findViewById(R.id.equipBox);
        remindersSwitch = findViewById(R.id.remindersSwitch);
        consentBox = findViewById(R.id.consentBox);

        // Fixed ids let Android restore selections after rotation.
        fillRadios(goalGroup, GOALS, 1100);
        fillRadios(levelGroup, LEVELS, 1200);
        fillRadios(lowerGroup, LOWER, 1300);
        fillRadios(durationGroup, DURATIONS, 1400);
        fillRadios(dietGroup, DIETS, 1500);
        fillRadios(unitsGroup, UNITS, 1600);
        fillChecks(limitsBox, LIMITS, 2100);
        fillChecks(equipBox, EQUIPMENT, 2200);

        prefillFromStore();

        if (savedInstanceState != null) {
            step = savedInstanceState.getInt(KEY_STEP, 0);
        }

        btnPrev.setOnClickListener(v -> goBack());
        btnNext.setOnClickListener(v -> goNext());
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (step > 0) {
                    goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });
        showStep();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_STEP, step);
    }

    private int sp18(int dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                getResources().getDisplayMetrics());
    }

    private void fillRadios(RadioGroup group, String[] options, int baseId) {
        for (int i = 0; i < options.length; i++) {
            MaterialRadioButton rb = new MaterialRadioButton(this);
            rb.setId(baseId + i);
            rb.setText(options[i]);
            rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            rb.setMinHeight(sp18(56));
            rb.setLayoutParams(new RadioGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            group.addView(rb);
        }
    }

    private void fillChecks(LinearLayout box, String[] options, int baseId) {
        for (int i = 0; i < options.length; i++) {
            MaterialCheckBox cb = new MaterialCheckBox(this);
            cb.setId(baseId + i);
            cb.setText(options[i]);
            cb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            cb.setMinHeight(sp18(56));
            box.addView(cb, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
    }

    /** When editing an existing profile, show the saved answers. */
    private void prefillFromStore() {
        if (!store.isOnboarded()) return;
        nameInput.setText(store.getString(ProfileStore.NAME, ""));
        ageInput.setText(store.getString(ProfileStore.AGE, ""));
        allergiesInput.setText(store.getString(ProfileStore.ALLERGIES, ""));
        healthInput.setText(store.getString(ProfileStore.HEALTH_NOTES, ""));
        remindersSwitch.setChecked(store.getBoolean(ProfileStore.REMINDERS, false));
        select(goalGroup, store.getString(ProfileStore.GOAL, ""));
        select(levelGroup, store.getString(ProfileStore.LEVEL, ""));
        select(lowerGroup, store.getString(ProfileStore.LOWER_BODY, ""));
        select(durationGroup, store.getString(ProfileStore.DURATION, ""));
        select(dietGroup, store.getString(ProfileStore.DIET, ""));
        select(unitsGroup, store.getString(ProfileStore.UNITS, ""));
        check(limitsBox, store.getSet(ProfileStore.LIMITS));
        check(equipBox, store.getSet(ProfileStore.EQUIPMENT));
    }

    private void select(RadioGroup g, String text) {
        for (int i = 0; i < g.getChildCount(); i++) {
            RadioButton rb = (RadioButton) g.getChildAt(i);
            if (rb.getText().toString().equals(text)) {
                g.check(rb.getId());
                return;
            }
        }
    }

    private void check(LinearLayout box, Set<String> values) {
        for (int i = 0; i < box.getChildCount(); i++) {
            CheckBox cb = (CheckBox) box.getChildAt(i);
            cb.setChecked(values.contains(cb.getText().toString()));
        }
    }

    private String selected(RadioGroup g) {
        int id = g.getCheckedRadioButtonId();
        if (id == -1) return "";
        RadioButton rb = g.findViewById(id);
        return rb == null ? "" : rb.getText().toString();
    }

    private Set<String> checked(LinearLayout box) {
        Set<String> out = new HashSet<>();
        for (int i = 0; i < box.getChildCount(); i++) {
            CheckBox cb = (CheckBox) box.getChildAt(i);
            if (cb.isChecked()) out.add(cb.getText().toString());
        }
        return out;
    }

    private String text(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }

    private void showStep() {
        for (int i = 0; i < STEPS; i++) {
            stepViews[i].setVisibility(i == step ? View.VISIBLE : View.GONE);
        }
        stepLabel.setText("Step " + (step + 1) + " of " + STEPS);
        progress.setProgressCompat(step + 1, true);
        btnPrev.setVisibility(step == 0 ? View.INVISIBLE : View.VISIBLE);
        btnNext.setText(step == STEPS - 1 ? R.string.finish : R.string.next);
        scroll.scrollTo(0, 0);
    }

    private void goBack() {
        if (step > 0) {
            step--;
            showStep();
        }
    }

    private void goNext() {
        if (!validateStep()) return;
        if (step < STEPS - 1) {
            step++;
            showStep();
        } else {
            saveAndFinish();
        }
    }

    private boolean needChoice(RadioGroup g) {
        if (g.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, R.string.choose_option, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private boolean validateStep() {
        switch (step) {
            case 0:
                if (text(nameInput).isEmpty()) {
                    nameInput.setError(getString(R.string.err_name));
                    nameInput.requestFocus();
                    return false;
                }
                int age;
                try {
                    age = Integer.parseInt(text(ageInput));
                } catch (NumberFormatException e) {
                    age = -1;
                }
                if (age < 13 || age > 110) {
                    ageInput.setError(getString(R.string.err_age));
                    ageInput.requestFocus();
                    return false;
                }
                return true;
            case 1:
                return needChoice(goalGroup) && needChoice(levelGroup);
            case 2:
                return needChoice(lowerGroup);
            case 3:
                return needChoice(durationGroup) && needChoice(dietGroup) && needChoice(unitsGroup);
            default:
                if (!consentBox.isChecked()) {
                    Toast.makeText(this, R.string.err_consent, Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
        }
    }

    private void saveAndFinish() {
        store.putString(ProfileStore.NAME, text(nameInput));
        store.putString(ProfileStore.AGE, text(ageInput));
        store.putString(ProfileStore.GOAL, selected(goalGroup));
        store.putString(ProfileStore.LEVEL, selected(levelGroup));
        store.putString(ProfileStore.LOWER_BODY, selected(lowerGroup));
        store.putSet(ProfileStore.LIMITS, checked(limitsBox));
        store.putSet(ProfileStore.EQUIPMENT, checked(equipBox));
        store.putString(ProfileStore.DURATION, selected(durationGroup));
        store.putString(ProfileStore.DIET, selected(dietGroup));
        store.putString(ProfileStore.ALLERGIES, text(allergiesInput));
        store.putString(ProfileStore.UNITS, selected(unitsGroup));
        store.putString(ProfileStore.HEALTH_NOTES, text(healthInput));
        store.putBoolean(ProfileStore.REMINDERS, remindersSwitch.isChecked());
        store.setOnboarded(true);

        Intent i = new Intent(this, HomeActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
}
