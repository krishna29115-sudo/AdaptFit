package com.adaptfit.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.adaptfit.app.data.Exercise;
import com.adaptfit.app.data.HistoryStore;
import com.adaptfit.app.data.ProfileStore;
import com.adaptfit.app.data.SessionRecord;
import com.adaptfit.app.data.WorkoutPlanner;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Shows today's tailored plan for Workout or Adaptive Yoga and starts the guided session. */
public class PlanActivity extends AppCompatActivity {
    public static final String EXTRA_MODE = "mode";

    private static final String STATE_DURATION = "duration";
    private static final String STATE_VARIATION = "variation";
    private static final String[] LENGTHS = {"5 minutes", "10 minutes", "15 minutes", "20 minutes or more"};

    private Exercise.Mode mode;
    private ProfileStore profile;
    private HistoryStore history;
    private WorkoutPlanner.Plan plan;
    private String durationOverride;
    private int variation;

    private TextView planSummary;
    private TextView planNotes;
    private TextView planList;
    private TextView weekSummary;
    private TextView recentList;
    private MaterialCheckBox checkReady;
    private MaterialButton btnStart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plan);

        mode = "YOGA".equals(getIntent().getStringExtra(EXTRA_MODE)) ? Exercise.Mode.YOGA : Exercise.Mode.WORKOUT;
        profile = new ProfileStore(this);
        history = new HistoryStore(this);
        if (savedInstanceState != null) {
            durationOverride = savedInstanceState.getString(STATE_DURATION);
            variation = savedInstanceState.getInt(STATE_VARIATION, 0);
        }

        ((TextView) findViewById(R.id.planTitle)).setText(
                mode == Exercise.Mode.YOGA ? R.string.plan_title_yoga : R.string.plan_title_workout);
        planSummary = findViewById(R.id.planSummary);
        planNotes = findViewById(R.id.planNotes);
        planList = findViewById(R.id.planList);
        weekSummary = findViewById(R.id.weekSummary);
        recentList = findViewById(R.id.recentList);
        checkReady = findViewById(R.id.checkReady);
        btnStart = findViewById(R.id.btnStart);

        checkReady.setOnCheckedChangeListener((b, checked) -> updateStartEnabled());
        btnStart.setOnClickListener(v -> startSession());
        findViewById(R.id.btnChangeLength).setOnClickListener(v -> chooseLength());
        findViewById(R.id.btnShuffle).setOnClickListener(v -> {
            variation++;
            refresh();
        });
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString(STATE_DURATION, durationOverride);
        out.putInt(STATE_VARIATION, variation);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        // Coming back from a session: ask for the safety confirmation again next time.
        checkReady.setChecked(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private String modeName() {
        return mode.name();
    }

    private String currentDuration() {
        return durationOverride != null ? durationOverride : profile.getString(ProfileStore.DURATION, "10 minutes");
    }

    private void refresh() {
        List<String> recent = history.recentFeelings(modeName(), 2);
        int adjust = WorkoutPlanner.adjustFromFeelings(recent);
        long seed = history.count(modeName()) * 31L + variation * 7919L + mode.ordinal();
        plan = WorkoutPlanner.build(
                mode,
                profile.getString(ProfileStore.GOAL, ""),
                profile.getString(ProfileStore.LEVEL, ""),
                profile.getSet(ProfileStore.LIMITS),
                profile.getSet(ProfileStore.EQUIPMENT),
                currentDuration(),
                adjust,
                seed);

        if (plan.items.isEmpty()) {
            planSummary.setText(R.string.plan_no_exercises);
            planList.setText("");
        } else {
            int minutes = Math.max(1, Math.round(plan.totalSeconds / 60f));
            planSummary.setText("About " + minutes + " minutes, " + plan.items.size() + " exercises. "
                    + "Each exercise lasts " + plan.exerciseSeconds + " seconds with "
                    + plan.restSeconds + " seconds of rest.");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < plan.items.size(); i++) {
                WorkoutPlanner.Item it = plan.items.get(i);
                sb.append(i + 1).append(". ").append(it.exercise.name);
                if (it.round > 1) sb.append(" (round ").append(it.round).append(")");
                sb.append('\n');
            }
            planList.setText(sb.toString().trim());
        }

        StringBuilder notes = new StringBuilder();
        for (String n : plan.notes) {
            if (notes.length() > 0) notes.append('\n');
            notes.append(n);
        }
        planNotes.setText(notes.toString());
        planNotes.setVisibility(notes.length() == 0 ? android.view.View.GONE : android.view.View.VISIBLE);

        renderHistory();
        updateStartEnabled();
    }

    private void updateStartEnabled() {
        btnStart.setEnabled(checkReady.isChecked() && plan != null && !plan.items.isEmpty());
    }

    private void renderHistory() {
        List<SessionRecord> all = history.getAllNewestFirst();
        long weekAgo = System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000;
        int sessions = 0;
        int seconds = 0;
        for (SessionRecord r : all) {
            if (r.timeMillis >= weekAgo && r.completed > 0) {
                sessions++;
                seconds += r.seconds;
            }
        }
        if (all.isEmpty()) {
            weekSummary.setText(R.string.plan_no_history);
            recentList.setText("");
            return;
        }
        weekSummary.setText("Last 7 days: " + sessions + (sessions == 1 ? " session, " : " sessions, ")
                + Math.round(seconds / 60f) + " minutes of activity.");
        SimpleDateFormat fmt = new SimpleDateFormat("d MMM, h:mm a", Locale.getDefault());
        StringBuilder sb = new StringBuilder();
        int shown = 0;
        for (SessionRecord r : all) {
            if (shown++ >= 5) break;
            if (sb.length() > 0) sb.append('\n');
            sb.append(fmt.format(new Date(r.timeMillis))).append(" - ")
                    .append("YOGA".equals(r.mode) ? "Yoga" : "Workout").append(", ")
                    .append(r.completed).append(" of ").append(r.planned).append(" exercises, ")
                    .append(Math.max(1, Math.round(r.seconds / 60f))).append(" min");
            if (r.stoppedEarly) sb.append(" (stopped early)");
        }
        recentList.setText(sb.toString());
    }

    private void chooseLength() {
        String current = currentDuration();
        int checked = 1;
        for (int i = 0; i < LENGTHS.length; i++) {
            if (LENGTHS[i].equals(current)) checked = i;
        }
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.plan_change_length)
                .setSingleChoiceItems(LENGTHS, checked, (d, which) -> {
                    durationOverride = LENGTHS[which];
                    d.dismiss();
                    refresh();
                })
                .setNegativeButton(R.string.back, null)
                .show();
    }

    private void startSession() {
        if (plan == null || plan.items.isEmpty()) return;
        String[] ids = new String[plan.items.size()];
        for (int i = 0; i < ids.length; i++) ids[i] = plan.items.get(i).exercise.id;
        Intent i = new Intent(this, SessionActivity.class);
        i.putExtra(SessionActivity.EXTRA_MODE, modeName());
        i.putExtra(SessionActivity.EXTRA_IDS, ids);
        i.putExtra(SessionActivity.EXTRA_EX_SECONDS, plan.exerciseSeconds);
        i.putExtra(SessionActivity.EXTRA_REST_SECONDS, plan.restSeconds);
        startActivity(i);
    }
}
