package com.adaptfit.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.adaptfit.app.data.HistoryStore;
import com.adaptfit.app.data.ProfileStore;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.Set;

public class ProfileActivity extends AppCompatActivity {
    private ProfileStore store;
    private TextView summary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        store = new ProfileStore(this);
        summary = findViewById(R.id.profileSummary);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnEdit).setOnClickListener(v ->
                startActivity(new Intent(this, OnboardingActivity.class)));
        findViewById(R.id.btnDelete).setOnClickListener(v -> confirmDelete());
    }

    @Override
    protected void onResume() {
        super.onResume();
        summary.setText(buildSummary());
    }

    private String line(String label, String value) {
        return label + ": " + (value == null || value.isEmpty() ? "Not provided" : value) + "\n";
    }

    private String join(Set<String> set) {
        return set.isEmpty() ? "" : android.text.TextUtils.join(", ", set);
    }

    private String buildSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append(line("Name", store.getString(ProfileStore.NAME, "")));
        sb.append(line("Age", store.getString(ProfileStore.AGE, "")));
        sb.append(line("Main goal", store.getString(ProfileStore.GOAL, "")));
        sb.append(line("Activity level", store.getString(ProfileStore.LEVEL, "")));
        sb.append(line("Lower-body mobility", store.getString(ProfileStore.LOWER_BODY, "")));
        sb.append(line("Adaptations", join(store.getSet(ProfileStore.LIMITS))));
        sb.append(line("Equipment", join(store.getSet(ProfileStore.EQUIPMENT))));
        sb.append(line("Workout length", store.getString(ProfileStore.DURATION, "")));
        sb.append(line("Eating preference", store.getString(ProfileStore.DIET, "")));
        sb.append(line("Allergies or foods to avoid", store.getString(ProfileStore.ALLERGIES, "")));
        sb.append(line("Units", store.getString(ProfileStore.UNITS, "")));
        sb.append(line("Health notes", store.getString(ProfileStore.HEALTH_NOTES, "")));
        sb.append(line("Reminders", store.getBoolean(ProfileStore.REMINDERS, false) ? "Yes" : "No"));
        return sb.toString();
    }

    private void confirmDelete() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Delete all my data?")
                .setMessage("This permanently removes your profile and workout history from this phone. This cannot be undone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> {
                    store.clearAll();
                    new HistoryStore(this).clearAll();
                    Intent i = new Intent(this, OnboardingActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                })
                .show();
    }
}
