package com.adaptfit.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import com.adaptfit.app.data.Exercise;
import com.adaptfit.app.data.ExerciseLibrary;
import com.adaptfit.app.data.HistoryStore;
import com.adaptfit.app.data.SessionRecord;
import com.adaptfit.app.data.WorkoutPlanner;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Runs a session one step at a time. Segments alternate: rest/get-ready, exercise, rest, exercise...
 * Segment 0 is "get ready", so segment 2k+1 is exercise k.
 * The timer pauses whenever the screen is left, so time is never lost silently.
 */
public class SessionActivity extends AppCompatActivity {
    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_IDS = "ids";
    public static final String EXTRA_EX_SECONDS = "ex_seconds";
    public static final String EXTRA_REST_SECONDS = "rest_seconds";

    private static final String S_SEGMENT = "segment";
    private static final String S_REMAINING = "remaining";
    private static final String S_COMPLETED = "completed";
    private static final String S_ACTIVE = "active";
    private static final String S_DONE = "done";
    private static final String S_EARLY = "early";
    private static final String S_UNWELL = "unwell";
    private static final String S_FEELING = "feeling";

    private final List<Exercise> exercises = new ArrayList<>();
    private String modeName;
    private int exSeconds;
    private int restSeconds;

    private int segment;
    private long remainingMs;
    private boolean running;
    private CountDownTimer timer;
    private int completed;
    private long activeMs;

    private boolean done;
    private boolean stoppedEarly;
    private boolean unwell;
    private String feeling;

    private HistoryStore history;

    private View sessionGroup;
    private View doneGroup;
    private TextView phaseLabel;
    private TextView exTitle;
    private TextView timerText;
    private TextView exSteps;
    private TextView exSafety;
    private TextView exEasier;
    private LinearProgressIndicator segmentProgress;
    private MaterialButton btnPause;
    private MaterialButton btnSkip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_session);
        history = new HistoryStore(this);

        modeName = getIntent().getStringExtra(EXTRA_MODE);
        if (modeName == null) modeName = "WORKOUT";
        exSeconds = getIntent().getIntExtra(EXTRA_EX_SECONDS, 40);
        restSeconds = getIntent().getIntExtra(EXTRA_REST_SECONDS, 10);
        String[] ids = getIntent().getStringArrayExtra(EXTRA_IDS);
        if (ids != null) {
            for (String id : ids) {
                Exercise e = ExerciseLibrary.byId(id);
                if (e != null) exercises.add(e);
            }
        }
        if (exercises.isEmpty()) {
            finish();
            return;
        }

        sessionGroup = findViewById(R.id.sessionGroup);
        doneGroup = findViewById(R.id.doneGroup);
        phaseLabel = findViewById(R.id.phaseLabel);
        exTitle = findViewById(R.id.exTitle);
        timerText = findViewById(R.id.timerText);
        exSteps = findViewById(R.id.exSteps);
        exSafety = findViewById(R.id.exSafety);
        exEasier = findViewById(R.id.exEasier);
        segmentProgress = findViewById(R.id.segmentProgress);
        btnPause = findViewById(R.id.btnPause);
        btnSkip = findViewById(R.id.btnSkip);

        btnPause.setOnClickListener(v -> {
            if (running) pauseTimer(); else startTimer();
        });
        btnSkip.setOnClickListener(v -> finishSegment(false));
        findViewById(R.id.btnUnwell).setOnClickListener(v -> endSession(true, true));
        findViewById(R.id.btnStop).setOnClickListener(v -> confirmStop());
        findViewById(R.id.btnFeelEasy).setOnClickListener(v -> rate(WorkoutPlanner.FEEL_EASY));
        findViewById(R.id.btnFeelRight).setOnClickListener(v -> rate(WorkoutPlanner.FEEL_RIGHT));
        findViewById(R.id.btnFeelHard).setOnClickListener(v -> rate(WorkoutPlanner.FEEL_HARD));
        findViewById(R.id.btnDone).setOnClickListener(v -> finish());
        findViewById(R.id.btnEmergency).setOnClickListener(v ->
                startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:112"))));

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (done) finish(); else confirmStop();
            }
        });

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        if (savedInstanceState != null) {
            segment = savedInstanceState.getInt(S_SEGMENT, 0);
            remainingMs = savedInstanceState.getLong(S_REMAINING, segmentTotalMs(segment));
            completed = savedInstanceState.getInt(S_COMPLETED, 0);
            activeMs = savedInstanceState.getLong(S_ACTIVE, 0);
            done = savedInstanceState.getBoolean(S_DONE, false);
            stoppedEarly = savedInstanceState.getBoolean(S_EARLY, false);
            unwell = savedInstanceState.getBoolean(S_UNWELL, false);
            feeling = savedInstanceState.getString(S_FEELING);
        } else {
            segment = 0;
            remainingMs = segmentTotalMs(0);
        }

        if (done) {
            showDone();
        } else {
            renderSegment();
            // A fresh start begins counting at once; a restored session waits for the person to resume.
            if (savedInstanceState == null) startTimer(); else setPausedUi();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt(S_SEGMENT, segment);
        out.putLong(S_REMAINING, remainingMs);
        out.putInt(S_COMPLETED, completed);
        out.putLong(S_ACTIVE, activeMs);
        out.putBoolean(S_DONE, done);
        out.putBoolean(S_EARLY, stoppedEarly);
        out.putBoolean(S_UNWELL, unwell);
        out.putString(S_FEELING, feeling);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (!done && running) pauseTimer();
    }

    @Override
    protected void onDestroy() {
        cancelTimer();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ segments

    private boolean isRest(int s) {
        return s % 2 == 0;
    }

    private int exerciseIndex(int s) {
        return s / 2;
    }

    private int lastSegment() {
        return exercises.size() * 2 - 1;
    }

    private long segmentTotalMs(int s) {
        if (!isRest(s)) return exSeconds * 1000L;
        return (s == 0 ? WorkoutPlanner.GET_READY_SECONDS : restSeconds) * 1000L;
    }

    private void renderSegment() {
        Exercise ex = exercises.get(Math.min(exerciseIndex(segment), exercises.size() - 1));
        int number = exerciseIndex(segment) + 1;
        int total = exercises.size();
        if (isRest(segment)) {
            phaseLabel.setText((segment == 0 ? "Get ready." : "Rest.") + " Next, exercise "
                    + number + " of " + total + ": " + ex.name);
            exTitle.setText("Next: " + ex.name);
            btnSkip.setText(R.string.session_skip_rest);
        } else {
            phaseLabel.setText("Exercise " + number + " of " + total + ": " + ex.name);
            exTitle.setText(ex.name);
            btnSkip.setText(R.string.session_skip_exercise);
        }
        exSteps.setText(ex.steps);
        exSafety.setText("Safety: " + ex.safety);
        exEasier.setText("Easier option: " + ex.easier);
        updateTimerUi();
    }

    private void updateTimerUi() {
        long total = segmentTotalMs(segment);
        long seconds = (remainingMs + 999) / 1000;
        timerText.setText(String.format(Locale.getDefault(), "%d:%02d", seconds / 60, seconds % 60));
        int progress = total <= 0 ? 0 : (int) (1000 * (total - remainingMs) / total);
        segmentProgress.setProgress(Math.max(0, Math.min(1000, progress)));
    }

    private void startTimer() {
        cancelTimer();
        running = true;
        btnPause.setText(R.string.session_pause);
        timer = new CountDownTimer(remainingMs, 200) {
            @Override
            public void onTick(long ms) {
                remainingMs = ms;
                updateTimerUi();
            }

            @Override
            public void onFinish() {
                remainingMs = 0;
                running = false;
                finishSegment(true);
            }
        }.start();
    }

    private void pauseTimer() {
        cancelTimer();
        running = false;
        setPausedUi();
    }

    private void setPausedUi() {
        btnPause.setText(R.string.session_resume);
    }

    private void cancelTimer() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    /** natural = the timer ran out; otherwise the person skipped it. */
    private void finishSegment(boolean natural) {
        cancelTimer();
        running = false;
        long total = segmentTotalMs(segment);
        activeMs += Math.max(0, total - remainingMs);
        if (!isRest(segment) && natural) completed++;
        if (segment >= lastSegment()) {
            endSession(false, false);
            return;
        }
        segment++;
        remainingMs = segmentTotalMs(segment);
        renderSegment();
        startTimer();
    }

    // ------------------------------------------------------------------ ending

    private void confirmStop() {
        final boolean wasRunning = running;
        if (wasRunning) pauseTimer();
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.session_stop_title)
                .setMessage(R.string.session_stop_message)
                .setNegativeButton(R.string.session_keep_going, (d, w) -> {
                    if (wasRunning) startTimer();
                })
                .setPositiveButton(R.string.session_stop, (d, w) -> endSession(true, false))
                .setOnCancelListener(d -> {
                    if (wasRunning) startTimer();
                })
                .show();
    }

    private void endSession(boolean early, boolean wasUnwell) {
        if (done) return;
        cancelTimer();
        running = false;
        if (early) {
            activeMs += Math.max(0, segmentTotalMs(segment) - remainingMs);
        }
        done = true;
        stoppedEarly = early;
        unwell = wasUnwell;
        history.add(new SessionRecord(System.currentTimeMillis(), modeName, completed,
                exercises.size(), (int) (activeMs / 1000), early,
                wasUnwell ? WorkoutPlanner.FEEL_UNWELL : null));
        showDone();
    }

    private void showDone() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        sessionGroup.setVisibility(View.GONE);
        doneGroup.setVisibility(View.VISIBLE);

        TextView title = findViewById(R.id.doneTitle);
        TextView summary = findViewById(R.id.doneSummary);
        int minutes = Math.max(1, Math.round(activeMs / 60000f));
        String progressLine = completed == 0
                ? "No exercises were completed this time."
                : "You completed " + completed + " of " + exercises.size() + " exercises in about "
                + minutes + (minutes == 1 ? " minute." : " minutes.");

        if (unwell) {
            title.setText("Session stopped");
            summary.setText(getString(R.string.session_unwell_text));
        } else if (stoppedEarly) {
            title.setText("Session stopped");
            summary.setText(progressLine + " Stopping when you need to is always fine.");
        } else {
            title.setText("Well done!");
            summary.setText(progressLine);
        }

        boolean canRate = !unwell && completed > 0;
        findViewById(R.id.btnEmergency).setVisibility(unwell ? View.VISIBLE : View.GONE);
        TextView prompt = findViewById(R.id.feelPrompt);
        int rateVisibility = canRate && feeling == null ? View.VISIBLE : View.GONE;
        prompt.setVisibility(canRate ? View.VISIBLE : View.GONE);
        prompt.setText(feeling == null ? getString(R.string.session_how_felt) : getString(R.string.feel_thanks));
        findViewById(R.id.btnFeelEasy).setVisibility(rateVisibility);
        findViewById(R.id.btnFeelRight).setVisibility(rateVisibility);
        findViewById(R.id.btnFeelHard).setVisibility(rateVisibility);
    }

    private void rate(String value) {
        if (feeling != null) return;
        feeling = value;
        history.setLatestFeeling(value);
        showDone();
    }
}
