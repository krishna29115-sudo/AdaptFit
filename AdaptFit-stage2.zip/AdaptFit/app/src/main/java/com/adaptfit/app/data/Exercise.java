package com.adaptfit.app.data;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/** One seated / supported exercise or yoga pose. Plain data, no Android classes. */
public final class Exercise {
    public enum Mode { WORKOUT, YOGA, BOTH }
    public enum Phase { WARMUP, MAIN, COOLDOWN }
    public enum Kind { STRENGTH, CARDIO, MOBILITY, CALM }

    public final String id;
    public final String name;
    public final Mode mode;
    public final Phase phase;
    public final Kind kind;
    /** 1 = very gentle, 2 = moderate, 3 = harder. */
    public final int intensity;
    /** Needs at least one of these items. Empty = needs nothing. */
    public final Set<String> needsAny;
    /** Left out when the person has any of these adaptations. */
    public final Set<String> avoidIf;
    public final String steps;
    public final String safety;
    public final String easier;

    private Exercise(Builder b) {
        id = b.id;
        name = b.name;
        mode = b.mode;
        phase = b.phase;
        kind = b.kind;
        intensity = b.intensity;
        needsAny = Collections.unmodifiableSet(new HashSet<>(b.needs));
        avoidIf = Collections.unmodifiableSet(new HashSet<>(b.avoid));
        steps = b.steps;
        safety = b.safety;
        easier = b.easier;
    }

    public boolean suits(Mode m) {
        return mode == Mode.BOTH || mode == m;
    }

    public static final class Builder {
        private final String id;
        private final String name;
        private Mode mode = Mode.WORKOUT;
        private Phase phase = Phase.MAIN;
        private Kind kind = Kind.STRENGTH;
        private int intensity = 1;
        private Set<String> needs = new HashSet<>();
        private Set<String> avoid = new HashSet<>();
        private String steps = "";
        private String safety = "";
        private String easier = "";

        public Builder(String id, String name) {
            this.id = id;
            this.name = name;
        }

        public Builder mode(Mode v) { mode = v; return this; }
        public Builder phase(Phase v) { phase = v; return this; }
        public Builder kind(Kind v) { kind = v; return this; }
        public Builder intensity(int v) { intensity = v; return this; }
        public Builder needs(String... v) { needs = new HashSet<>(Arrays.asList(v)); return this; }
        public Builder avoid(String... v) { avoid = new HashSet<>(Arrays.asList(v)); return this; }
        public Builder steps(String v) { steps = v; return this; }
        public Builder safety(String v) { safety = v; return this; }
        public Builder easier(String v) { easier = v; return this; }
        public Exercise build() { return new Exercise(this); }
    }
}
