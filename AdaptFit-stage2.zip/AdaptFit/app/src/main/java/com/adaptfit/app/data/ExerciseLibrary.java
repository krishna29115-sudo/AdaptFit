package com.adaptfit.app.data;

import static com.adaptfit.app.data.ProfileOptions.EQ_BALL;
import static com.adaptfit.app.data.ProfileOptions.EQ_BAND;
import static com.adaptfit.app.data.ProfileOptions.EQ_CHAIR;
import static com.adaptfit.app.data.ProfileOptions.EQ_DUMBBELL;
import static com.adaptfit.app.data.ProfileOptions.EQ_HOUSEHOLD;
import static com.adaptfit.app.data.ProfileOptions.LIM_GRIP;
import static com.adaptfit.app.data.ProfileOptions.LIM_SHOULDER;
import static com.adaptfit.app.data.ProfileOptions.LIM_TRUNK;

import com.adaptfit.app.data.Exercise.Kind;
import com.adaptfit.app.data.Exercise.Mode;
import com.adaptfit.app.data.Exercise.Phase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Every exercise in the app. All of them are done seated with the back supported, upper body only.
 * Nothing needs standing, transferring to the floor, or lower-body movement.
 * These are general wellness activities, not clinician-prescribed rehabilitation.
 */
public final class ExerciseLibrary {
    private ExerciseLibrary() {}

    private static final List<Exercise> ALL;

    static {
        List<Exercise> l = new ArrayList<>();

        // ---------------------------------------------------------------- shared warm-ups
        l.add(new Exercise.Builder("w_breath", "Seated posture and breathing")
                .mode(Mode.BOTH).phase(Phase.WARMUP).kind(Kind.CALM).intensity(1)
                .steps("Sit tall with your back supported and your hands resting on your lap. "
                        + "Breathe in slowly through your nose, then breathe out gently through your mouth, "
                        + "a little longer than the breath in. Let your shoulders drop.")
                .safety("Breathe at an easy pace. If you feel light-headed, breathe normally and rest.")
                .easier("Breathe in and out at whatever pace feels comfortable.")
                .build());
        l.add(new Exercise.Builder("w_shoulder_rolls", "Shoulder rolls")
                .mode(Mode.BOTH).phase(Phase.WARMUP).kind(Kind.MOBILITY).intensity(1)
                .steps("Lift your shoulders up, roll them back and down in a slow circle. "
                        + "After 5 or 6 rolls, change direction.")
                .safety("Keep the movement small and pain-free.")
                .easier("Make the circles smaller, or just lift and lower your shoulders.")
                .build());
        l.add(new Exercise.Builder("w_neck_tilts", "Gentle neck tilts")
                .mode(Mode.BOTH).phase(Phase.WARMUP).kind(Kind.MOBILITY).intensity(1)
                .steps("Slowly tilt your right ear towards your right shoulder, hold for 2 counts, "
                        + "come back to the centre, then tilt to the left. Keep your shoulders relaxed.")
                .safety("Move slowly. Do not roll your head in full circles and do not tilt past a comfortable stretch.")
                .easier("Tilt only a little and keep looking straight ahead.")
                .build());
        l.add(new Exercise.Builder("w_wrist_circles", "Wrist and finger circles")
                .mode(Mode.BOTH).phase(Phase.WARMUP).kind(Kind.MOBILITY).intensity(1)
                .steps("Rest your forearms on your lap or a table. Circle your wrists slowly one way, "
                        + "then the other. Then open and close your hands.")
                .safety("Stay gentle with your hands and wrists.")
                .easier("Just open and close your hands, or circle one wrist at a time.")
                .build());

        // ---------------------------------------------------------------- workout: strength
        l.add(new Exercise.Builder("s_palm_press", "Palm press")
                .mode(Mode.WORKOUT).kind(Kind.STRENGTH).intensity(1)
                .steps("Put your palms together in front of your chest. Press your palms firmly together "
                        + "for 3 counts, then relax. Repeat.")
                .safety("Press firmly but never to the point of pain. Breathe out as you press and do not hold your breath.")
                .easier("Press more gently, or for a shorter time.")
                .build());
        l.add(new Exercise.Builder("s_elbow_curls", "Elbow curls (no weight)")
                .mode(Mode.WORKOUT).kind(Kind.STRENGTH).intensity(1)
                .steps("With your elbows by your sides, bend both elbows to bring your hands towards your shoulders, "
                        + "then lower slowly. If a hand cannot close, curl with an open hand or your forearm.")
                .safety("Move slowly and keep your back supported by the chair.")
                .easier("Use a smaller range of movement.")
                .build());
        l.add(new Exercise.Builder("s_shoulder_squeeze", "Shoulder blade squeeze")
                .mode(Mode.WORKOUT).kind(Kind.STRENGTH).intensity(1)
                .steps("Sit tall. Gently draw your shoulder blades back and towards each other, as if tucking them "
                        + "into your back pockets. Hold for 3 counts, then release.")
                .safety("Do not arch your lower back. Keep the movement small and slow.")
                .easier("Squeeze more gently, or hold for 1 or 2 counts.")
                .build());
        l.add(new Exercise.Builder("s_table_press", "Tabletop press")
                .mode(Mode.WORKOUT).kind(Kind.STRENGTH).intensity(1).needs(EQ_CHAIR)
                .steps("Rest your forearms on a sturdy table with your palms facing down. Press your palms down "
                        + "into the table for 3 counts, then relax. Repeat.")
                .safety("Use a table that cannot move or tip. Do not lean your weight forwards.")
                .easier("Press more gently, or press with your forearms instead of your palms.")
                .build());
        l.add(new Exercise.Builder("s_ball_squeeze", "Ball squeeze")
                .mode(Mode.WORKOUT).kind(Kind.STRENGTH).intensity(1).needs(EQ_BALL)
                .steps("Hold the ball between your palms in front of your chest. You do not need to grip it. "
                        + "Squeeze your palms together for 3 counts, then relax.")
                .safety("Keep the ball at chest height and your back supported.")
                .easier("Squeeze more gently.")
                .build());
        l.add(new Exercise.Builder("s_overhead_reach", "Overhead reach")
                .mode(Mode.WORKOUT).kind(Kind.STRENGTH).intensity(2).avoid(LIM_SHOULDER, LIM_TRUNK)
                .steps("Raise both arms up beside your ears as far as is comfortable, then lower them slowly. "
                        + "Keep your back against the chair.")
                .safety("Stop at a height that feels comfortable. Do not lean back to reach higher.")
                .easier("Raise your arms only to shoulder height.")
                .build());
        l.add(new Exercise.Builder("s_band_pull_apart", "Band pull-apart")
                .mode(Mode.WORKOUT).kind(Kind.STRENGTH).intensity(2).needs(EQ_BAND).avoid(LIM_GRIP)
                .steps("Hold the resistance band in both hands in front of your chest with your arms straight. "
                        + "Gently pull your hands apart, squeezing your shoulder blades together, then return slowly.")
                .safety("Check the band for cracks or tears first. Hold it so it cannot snap back towards your face.")
                .easier("Use a lighter band, or pull apart a shorter distance.")
                .build());
        l.add(new Exercise.Builder("s_weight_curls", "Weighted curls")
                .mode(Mode.WORKOUT).kind(Kind.STRENGTH).intensity(2).needs(EQ_DUMBBELL, EQ_HOUSEHOLD).avoid(LIM_GRIP)
                .steps("Hold a light dumbbell or a water bottle in each hand with your arms by your sides. "
                        + "Bend your elbows to lift the weights towards your shoulders, then lower slowly.")
                .safety("Choose a weight you could lift about 10 times comfortably. Stop if you feel pain.")
                .easier("Use a lighter weight, or no weight.")
                .build());
        l.add(new Exercise.Builder("s_front_raise", "Front raise")
                .mode(Mode.WORKOUT).kind(Kind.STRENGTH).intensity(2).needs(EQ_DUMBBELL, EQ_HOUSEHOLD)
                .avoid(LIM_SHOULDER, LIM_GRIP)
                .steps("Hold a light weight in each hand in front of your thighs. Raise both arms forward to "
                        + "chest height, then lower slowly.")
                .safety("Keep your back supported and do not swing the weights.")
                .easier("Use a lighter weight, or no weight.")
                .build());
        l.add(new Exercise.Builder("s_shoulder_press", "Shoulder press")
                .mode(Mode.WORKOUT).kind(Kind.STRENGTH).intensity(3).needs(EQ_DUMBBELL, EQ_HOUSEHOLD)
                .avoid(LIM_SHOULDER, LIM_GRIP, LIM_TRUNK)
                .steps("Hold a light weight in each hand at shoulder height. Press both hands up until your arms "
                        + "are nearly straight, then lower slowly.")
                .safety("Use a light weight. Keep your back against the chair and breathe out as you press.")
                .easier("Use a lighter weight, or press only part of the way up.")
                .build());

        // ---------------------------------------------------------------- workout: cardio
        l.add(new Exercise.Builder("c_arm_swings", "Seated arm swings")
                .mode(Mode.WORKOUT).kind(Kind.CARDIO).intensity(2)
                .steps("Swing your arms gently forwards and backwards in a steady rhythm, like marching with your arms. "
                        + "Keep the swings below shoulder height.")
                .safety("Keep your back supported and your breathing easy. You should still be able to talk.")
                .easier("Swing your arms slowly with small movements.")
                .build());
        l.add(new Exercise.Builder("c_running_arms", "Running arms")
                .mode(Mode.WORKOUT).kind(Kind.CARDIO).intensity(2)
                .steps("Bend your elbows to about a right angle and pump your arms back and forth like running, "
                        + "with relaxed shoulders and a steady rhythm.")
                .safety("Keep your back against the chair. Slow down if you feel breathless.")
                .easier("Pump your arms slowly, or one arm at a time.")
                .build());
        l.add(new Exercise.Builder("c_punches", "Straight punches")
                .mode(Mode.WORKOUT).kind(Kind.CARDIO).intensity(2).avoid(LIM_TRUNK)
                .steps("Punch forward with one hand at a time at chest height. Keep your chest and hips facing "
                        + "forward. Do not twist.")
                .safety("Keep your back against the chair and your balance steady.")
                .easier("Punch slowly and not all the way out.")
                .build());
        l.add(new Exercise.Builder("c_ball_pass", "Ball pass")
                .mode(Mode.WORKOUT).kind(Kind.CARDIO).intensity(2).needs(EQ_BALL).avoid(LIM_GRIP)
                .steps("Pass the ball from one hand to the other in front of your chest at a steady rhythm. "
                        + "Keep your chest facing forward.")
                .safety("Pass the ball only as far as you can control it without leaning.")
                .easier("Pass the ball slowly, or roll it between your palms.")
                .build());
        l.add(new Exercise.Builder("c_fast_punches", "Boxing rhythm")
                .mode(Mode.WORKOUT).kind(Kind.CARDIO).intensity(3).avoid(LIM_TRUNK)
                .steps("Punch forward quickly with alternating hands at chest height, keeping a steady beat. "
                        + "Keep your chest and hips facing forward. Do not twist.")
                .safety("Stop or slow down straight away if you feel dizzy, breathless or any pain.")
                .easier("Slow the beat right down, or use the Straight punches pace.")
                .build());
        l.add(new Exercise.Builder("c_big_circles", "Big arm circles")
                .mode(Mode.WORKOUT).kind(Kind.CARDIO).intensity(3).avoid(LIM_SHOULDER, LIM_TRUNK)
                .steps("Hold your arms out to the sides at about shoulder height and make large, smooth circles. "
                        + "Change direction halfway through.")
                .safety("Keep your back against the chair. Make the circles smaller if your shoulders feel strained.")
                .easier("Make the circles smaller, or keep your arms lower.")
                .build());

        // ---------------------------------------------------------------- shared gentle mobility (main)
        l.add(new Exercise.Builder("m_wrist_stretch", "Wrist and finger stretch")
                .mode(Mode.BOTH).kind(Kind.MOBILITY).intensity(1)
                .steps("Rest your right forearm on your lap or a table with the palm up. Use your left palm to "
                        + "ease the fingers gently back until you feel a mild stretch. Hold, then switch hands.")
                .safety("Stretch only to a gentle tension, never pain. If your hands have reduced feeling, use a smaller stretch.")
                .easier("Stretch for a shorter time, or just open and close your hands.")
                .build());
        l.add(new Exercise.Builder("m_chest_opener", "Chest opener")
                .mode(Mode.BOTH).kind(Kind.MOBILITY).intensity(1).avoid(LIM_SHOULDER)
                .steps("Sit tall. Open your arms out to the sides at a comfortable height with your palms "
                        + "facing forward, and feel a gentle stretch across your chest. Hold for 3 slow breaths.")
                .safety("Keep your back against the chair. Do not push your arms back further than is comfortable.")
                .easier("Open your arms only part of the way.")
                .build());
        l.add(new Exercise.Builder("m_shoulder_squeeze", "Shoulder blade release")
                .mode(Mode.BOTH).kind(Kind.MOBILITY).intensity(1)
                .steps("Sit tall. Gently draw your shoulder blades back and together, hold for 2 counts, "
                        + "then let them soften forward again. Move with your breath.")
                .safety("Keep it small and slow. Do not arch your lower back.")
                .easier("Squeeze more gently.")
                .build());
        l.add(new Exercise.Builder("m_chin_nods", "Chin nods")
                .mode(Mode.BOTH).kind(Kind.MOBILITY).intensity(1)
                .steps("Look straight ahead. Gently glide your chin straight back, as if making a small double chin, "
                        + "hold for 3 counts, then relax.")
                .safety("Keep the movement small and comfortable. Stop if you feel any pain, tingling or dizziness.")
                .easier("Glide your chin back only a little.")
                .build());
        l.add(new Exercise.Builder("m_side_reach", "Seated side reach")
                .mode(Mode.WORKOUT).kind(Kind.MOBILITY).intensity(1).avoid(LIM_TRUNK)
                .steps("Rest your left hand on your thigh or armrest for support. Reach your right arm up and "
                        + "gently over to the left, leaning only a little. Return to the centre, then switch sides.")
                .safety("Lean only as far as you can return from easily without using your hands to push yourself up.")
                .easier("Reach your arm up without leaning.")
                .build());

        // ---------------------------------------------------------------- shared cool-downs
        l.add(new Exercise.Builder("d_slow_breathing", "Slow breathing")
                .mode(Mode.BOTH).phase(Phase.COOLDOWN).kind(Kind.CALM).intensity(1)
                .steps("Rest your hands on your lap. Breathe in slowly through your nose and out gently through "
                        + "your mouth. Let each breath out be a little longer than the breath in.")
                .safety("If you feel light-headed, breathe normally.")
                .easier("Breathe at whatever pace feels comfortable.")
                .build());
        l.add(new Exercise.Builder("d_cross_shoulder", "Cross-body shoulder stretch")
                .mode(Mode.BOTH).phase(Phase.COOLDOWN).kind(Kind.MOBILITY).intensity(1).avoid(LIM_SHOULDER)
                .steps("Bring your right arm across your chest. Rest your left hand on it, or on your upper arm, "
                        + "and ease it gently closer until you feel a mild stretch. Hold, then switch arms.")
                .safety("Stretch only to a gentle tension. Never pull on the joint.")
                .easier("Hold your arm lower, or hold for a shorter time.")
                .build());
        l.add(new Exercise.Builder("d_upper_back", "Upper back hug")
                .mode(Mode.WORKOUT).phase(Phase.COOLDOWN).kind(Kind.MOBILITY).intensity(1)
                .steps("Cross your arms and hold your opposite shoulders in a gentle hug. Keep your back against "
                        + "the chair and let your upper back round slightly. Breathe slowly.")
                .safety("Do not lean forward. Keep your back supported.")
                .easier("Rest your hands on your upper arms or lap instead of hugging.")
                .build());
        l.add(new Exercise.Builder("d_shake_out", "Hand shake-out")
                .mode(Mode.WORKOUT).phase(Phase.COOLDOWN).kind(Kind.MOBILITY).intensity(1)
                .steps("Let your hands rest loosely, then gently shake them out for a few seconds. "
                        + "Rest, and repeat.")
                .safety("Keep the shaking loose and light.")
                .easier("Just rest your hands on your lap and wiggle your fingers.")
                .build());
        l.add(new Exercise.Builder("d_rest", "Rest and relax")
                .mode(Mode.BOTH).phase(Phase.COOLDOWN).kind(Kind.CALM).intensity(1)
                .steps("Rest your hands on your lap. Close your eyes or soften your gaze. Notice your breathing "
                        + "slowing down. Relax your shoulders, jaw and forehead. If feeling is reduced in some "
                        + "areas, simply imagine those areas relaxing.")
                .safety("Stay seated and supported. When you are ready, open your eyes and move slowly.")
                .easier("Just breathe normally and rest.")
                .build());

        // ---------------------------------------------------------------- yoga: opening
        l.add(new Exercise.Builder("y_mountain", "Seated mountain pose")
                .mode(Mode.YOGA).phase(Phase.WARMUP).kind(Kind.CALM).intensity(1)
                .steps("Sit tall with your back supported and your hands resting on your thighs. Lengthen up "
                        + "through the top of your head and relax your shoulders. Breathe naturally.")
                .safety("Sit in a way that feels stable. If you use a wheelchair, check that the brakes are on.")
                .easier("Let your back rest fully against the chair.")
                .build());
        l.add(new Exercise.Builder("y_three_part_breath", "Three-part breath")
                .mode(Mode.YOGA).phase(Phase.WARMUP).kind(Kind.CALM).intensity(1)
                .steps("Breathe in slowly and feel your belly, then your ribs, then your upper chest rise. "
                        + "Breathe out slowly and feel them settle in the same order.")
                .safety("Never strain. If you feel light-headed, return to normal breathing.")
                .easier("Breathe in and out gently without thinking about the three parts.")
                .build());
        l.add(new Exercise.Builder("y_wrist_flow", "Wrist and finger flow")
                .mode(Mode.YOGA).phase(Phase.WARMUP).kind(Kind.MOBILITY).intensity(1)
                .steps("Stretch your arms forward at a comfortable height. Circle your wrists, then spread your "
                        + "fingers wide as you breathe in and make soft fists, or curl your fingers, as you breathe out.")
                .safety("Keep it gentle. Rest your forearms on your lap or a table if your arms tire.")
                .easier("Rest your forearms on your lap and just move your hands.")
                .build());

        // ---------------------------------------------------------------- yoga: flow
        l.add(new Exercise.Builder("y_sun_breath", "Sun breath arms")
                .mode(Mode.YOGA).kind(Kind.MOBILITY).intensity(1).avoid(LIM_SHOULDER, LIM_TRUNK)
                .steps("As you breathe in, sweep your arms out to the sides and up. As you breathe out, lower them "
                        + "slowly with your palms facing down. Move with your breath.")
                .safety("Keep your back against the chair. Raise your arms only as high as is comfortable.")
                .easier("Raise your arms only to chest height.")
                .build());
        l.add(new Exercise.Builder("y_cat_cow", "Seated cat and cow")
                .mode(Mode.YOGA).kind(Kind.MOBILITY).intensity(1).avoid(LIM_TRUNK)
                .steps("Rest your hands on your thighs. As you breathe in, gently lift your chest and look slightly "
                        + "up. As you breathe out, gently round your back and let your chin move towards your chest.")
                .safety("Keep the movements small, and keep your hands on your thighs for support.")
                .easier("Make the movements even smaller, or only round your upper back.")
                .build());
        l.add(new Exercise.Builder("y_side_bend", "Seated side bend")
                .mode(Mode.YOGA).kind(Kind.MOBILITY).intensity(1).avoid(LIM_TRUNK)
                .steps("Rest your left hand on your thigh or armrest for support. As you breathe in, raise your right "
                        + "arm. As you breathe out, lean gently to the left. Come back up and switch sides.")
                .safety("Lean only as far as you can come back from easily without pushing up with your hands.")
                .easier("Raise your arm without leaning.")
                .build());
        l.add(new Exercise.Builder("y_twist", "Gentle seated twist")
                .mode(Mode.YOGA).kind(Kind.MOBILITY).intensity(1).avoid(LIM_TRUNK)
                .steps("Sit tall. As you breathe out, gently turn your head and shoulders to look over your right "
                        + "shoulder, with a hand resting on your thigh or armrest. Breathe in to return to the centre, "
                        + "then turn to the left.")
                .safety("Turn only a little and never force the twist. Keep your hips still and your back supported.")
                .easier("Turn only your head and neck.")
                .build());
        l.add(new Exercise.Builder("y_cactus", "Cactus arms")
                .mode(Mode.YOGA).kind(Kind.MOBILITY).intensity(1).avoid(LIM_SHOULDER)
                .steps("Bend your elbows with your hands up beside your shoulders. As you breathe in, open your "
                        + "elbows back and squeeze your shoulder blades. As you breathe out, bring your elbows "
                        + "together in front of you.")
                .safety("Keep the movement within a comfortable range. Do not arch your lower back.")
                .easier("Make the movement smaller.")
                .build());
        l.add(new Exercise.Builder("y_forward_fold", "Seated forward fold")
                .mode(Mode.YOGA).kind(Kind.MOBILITY).intensity(1).avoid(LIM_TRUNK)
                .steps("Rest your hands on your thighs or a table. As you breathe in, lengthen your back. "
                        + "As you breathe out, lean forward a little, only as far as feels safe and steady. "
                        + "Breathe, then rise slowly.")
                .safety("Lean only as far as you can come back from without help. Rise slowly, as getting up quickly can cause dizziness.")
                .easier("Lean forward just a few centimetres, or skip this pose.")
                .build());
        l.add(new Exercise.Builder("y_box_breath", "Box breathing")
                .mode(Mode.YOGA).kind(Kind.CALM).intensity(1)
                .steps("Breathe in for a count of 4, pause gently for 4, breathe out for 4, pause gently for 4. "
                        + "Repeat at a pace that feels easy.")
                .safety("Skip the pauses if you feel light-headed, or if a health professional has advised you not to hold your breath.")
                .easier("Skip the pauses and just breathe in and out slowly.")
                .build());

        // ---------------------------------------------------------------- yoga: closing
        l.add(new Exercise.Builder("y_heart_centre", "Hands to heart")
                .mode(Mode.YOGA).phase(Phase.COOLDOWN).kind(Kind.CALM).intensity(1)
                .steps("Bring your palms together in front of your chest. Close your eyes or soften your gaze. "
                        + "Take three slow breaths, and let your shoulders soften with each breath out.")
                .safety("Stay seated and supported.")
                .easier("Rest your hands on your lap instead.")
                .build());

        ALL = Collections.unmodifiableList(l);
    }

    public static List<Exercise> all() {
        return ALL;
    }

    public static Exercise byId(String id) {
        for (Exercise e : ALL) {
            if (e.id.equals(id)) return e;
        }
        return null;
    }
}
