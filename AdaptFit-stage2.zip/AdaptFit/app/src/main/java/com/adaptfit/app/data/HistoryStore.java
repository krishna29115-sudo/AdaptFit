package com.adaptfit.app.data;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Workout history, stored in private app storage on this device only. */
public class HistoryStore {
    private static final String PREFS = "adaptfit_history";
    private static final String KEY = "sessions";
    private static final int MAX_ENTRIES = 200;

    private final SharedPreferences prefs;

    public HistoryStore(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Oldest first, exactly as stored. */
    private List<SessionRecord> load() {
        List<SessionRecord> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(prefs.getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                out.add(new SessionRecord(
                        o.getLong("t"), o.getString("m"), o.getInt("c"), o.getInt("p"),
                        o.getInt("s"), o.getBoolean("e"),
                        o.isNull("f") ? null : o.getString("f")));
            }
        } catch (JSONException ignored) {
            // Damaged data: start again with whatever was readable.
        }
        return out;
    }

    private void save(List<SessionRecord> list) {
        JSONArray arr = new JSONArray();
        int start = Math.max(0, list.size() - MAX_ENTRIES);
        try {
            for (int i = start; i < list.size(); i++) {
                SessionRecord r = list.get(i);
                JSONObject o = new JSONObject();
                o.put("t", r.timeMillis);
                o.put("m", r.mode);
                o.put("c", r.completed);
                o.put("p", r.planned);
                o.put("s", r.seconds);
                o.put("e", r.stoppedEarly);
                o.put("f", r.feeling == null ? JSONObject.NULL : r.feeling);
                arr.put(o);
            }
        } catch (JSONException ignored) {
            return;
        }
        prefs.edit().putString(KEY, arr.toString()).apply();
    }

    public void add(SessionRecord record) {
        List<SessionRecord> list = load();
        list.add(record);
        save(list);
    }

    /** Sets the rating on the most recent session. */
    public void setLatestFeeling(String feeling) {
        List<SessionRecord> list = load();
        if (list.isEmpty()) return;
        int last = list.size() - 1;
        list.set(last, list.get(last).withFeeling(feeling));
        save(list);
    }

    /** Newest first. */
    public List<SessionRecord> getAllNewestFirst() {
        List<SessionRecord> list = load();
        java.util.Collections.reverse(list);
        return list;
    }

    /** Ratings of recent sessions in this mode, newest first, skipping sessions without a rating. */
    public List<String> recentFeelings(String mode, int max) {
        List<String> out = new ArrayList<>();
        for (SessionRecord r : getAllNewestFirst()) {
            if (!r.mode.equals(mode) || r.feeling == null) continue;
            out.add(r.feeling);
            if (out.size() >= max) break;
        }
        return out;
    }

    public int count(String mode) {
        int n = 0;
        for (SessionRecord r : load()) {
            if (r.mode.equals(mode)) n++;
        }
        return n;
    }

    public void clearAll() {
        prefs.edit().clear().apply();
    }
}
