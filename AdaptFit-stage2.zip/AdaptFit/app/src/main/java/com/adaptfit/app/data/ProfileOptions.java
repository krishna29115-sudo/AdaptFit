package com.adaptfit.app.data;

/**
 * Option texts chosen in onboarding. They MUST match the arrays in OnboardingActivity exactly,
 * because the profile stores the chosen text itself.
 */
public final class ProfileOptions {
    private ProfileOptions() {}

    public static final String GOAL_STRENGTH = "Upper-body strength";
    public static final String GOAL_FLEX = "Flexibility and mobility";
    public static final String GOAL_STAMINA = "Improving stamina";
    public static final String GOAL_INDEPENDENCE = "Maintaining independence in daily activities";
    public static final String GOAL_RELAX = "Stress reduction and relaxation";

    public static final String LEVEL_START = "Just starting out";

    public static final String LIM_SHOULDER = "Limited shoulder mobility";
    public static final String LIM_GRIP = "Limited hand grip";
    public static final String LIM_TRUNK = "Limited trunk control";
    public static final String LIM_SENSATION = "Reduced sensation";
    public static final String LIM_TIRED = "Gets tired easily";
    public static final String LIM_GENTLE = "Prefer very gentle movement";

    public static final String EQ_BAND = "Resistance band";
    public static final String EQ_DUMBBELL = "Light dumbbells";
    public static final String EQ_HOUSEHOLD = "Water bottles or household items";
    public static final String EQ_BALL = "Exercise ball";
    public static final String EQ_CHAIR = "Sturdy chair or table";
}
