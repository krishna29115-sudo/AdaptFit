package com.adaptfit.app.data;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/** Stores the user's profile on this device only (private app storage). */
public class ProfileStore {
    public static final String NAME = "name";
    public static final String AGE = "age";
    public static final String GOAL = "goal";
    public static final String LEVEL = "level";
    public static final String LOWER_BODY = "lower_body";
    public static final String LIMITS = "limits";
    public static final String EQUIPMENT = "equipment";
    public static final String DURATION = "duration";
    public static final String DIET = "diet";
    public static final String ALLERGIES = "allergies";
    public static final String UNITS = "units";
    public static final String HEALTH_NOTES = "health_notes";
    public static final String REMINDERS = "reminders";
    private static final String ONBOARDED = "onboarded";
    private static final String PREFS = "adaptfit_profile";

    private final SharedPreferences prefs;

    public ProfileStore(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean isOnboarded() {
        return prefs.getBoolean(ONBOARDED, false);
    }

    public void setOnboarded(boolean value) {
        prefs.edit().putBoolean(ONBOARDED, value).apply();
    }

    public void putString(String key, String value) {
        prefs.edit().putString(key, value).apply();
    }

    public String getString(String key, String fallback) {
        return prefs.getString(key, fallback);
    }

    public void putBoolean(String key, boolean value) {
        prefs.edit().putBoolean(key, value).apply();
    }

    public boolean getBoolean(String key, boolean fallback) {
        return prefs.getBoolean(key, fallback);
    }

    public void putSet(String key, Set<String> value) {
        prefs.edit().putStringSet(key, new HashSet<>(value)).apply();
    }

    public Set<String> getSet(String key) {
        return new HashSet<>(prefs.getStringSet(key, new HashSet<String>()));
    }

    /** Deletes every piece of personal data stored by the profile. */
    public void clearAll() {
        prefs.edit().clear().apply();
    }
}
