package com.adaptfit.app.data;

/** One finished (or stopped) session, kept on this phone only. */
public final class SessionRecord {
    public final long timeMillis;
    public final String mode;       // "WORKOUT" or "YOGA"
    public final int completed;     // exercises finished
    public final int planned;       // exercises in the plan
    public final int seconds;       // active time
    public final boolean stoppedEarly;
    public final String feeling;    // WorkoutPlanner.FEEL_* or null

    public SessionRecord(long timeMillis, String mode, int completed, int planned, int seconds,
                         boolean stoppedEarly, String feeling) {
        this.timeMillis = timeMillis;
        this.mode = mode;
        this.completed = completed;
        this.planned = planned;
        this.seconds = seconds;
        this.stoppedEarly = stoppedEarly;
        this.feeling = feeling;
    }

    public SessionRecord withFeeling(String newFeeling) {
        return new SessionRecord(timeMillis, mode, completed, planned, seconds, stoppedEarly, newFeeling);
    }
}
