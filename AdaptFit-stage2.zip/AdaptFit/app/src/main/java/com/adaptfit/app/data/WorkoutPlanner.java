package com.adaptfit.app.data;

import com.adaptfit.app.data.Exercise.Kind;
import com.adaptfit.app.data.Exercise.Mode;
import com.adaptfit.app.data.Exercise.Phase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/** Builds a session from the person's profile. Pure Java so it can be tested without a phone. */
public final class WorkoutPlanner {
    private WorkoutPlanner() {}

    public static final String FEEL_EASY = "easy";
    public static final String FEEL_RIGHT = "right";
    public static final String FEEL_HARD = "hard";
    public static final String FEEL_UNWELL = "unwell";

    public static final int GET_READY_SECONDS = 10;

    public static final class Item {
        public final Exercise exercise;
        public final int round;

        Item(Exercise exercise, int round) {
            this.exercise = exercise;
            this.round = round;
        }
    }

    public static final class Plan {
        public final Mode mode;
        public final List<Item> items;
        public final int exerciseSeconds;
        public final int restSeconds;
        public final int intensityCap;
        public final int totalSeconds;
        public final List<String> notes;

        Plan(Mode mode, List<Item> items, int exerciseSeconds, int restSeconds, int intensityCap,
             List<String> notes) {
            this.mode = mode;
            this.items = Collections.unmodifiableList(items);
            this.exerciseSeconds = exerciseSeconds;
            this.restSeconds = restSeconds;
            this.intensityCap = intensityCap;
            this.notes = Collections.unmodifiableList(notes);
            int n = items.size();
            this.totalSeconds = n == 0 ? 0 : GET_READY_SECONDS + n * exerciseSeconds + (n - 1) * restSeconds;
        }
    }

    /** "5 minutes" gives 5, "20 minutes or more" gives 20, anything unreadable gives 10. */
    public static int parseMinutes(String duration) {
        if (duration == null) return 10;
        StringBuilder digits = new StringBuilder();
        for (char c : duration.toCharArray()) {
            if (Character.isDigit(c)) digits.append(c);
            else if (digits.length() > 0) break;
        }
        if (digits.length() == 0) return 10;
        int m = Integer.parseInt(digits.toString());
        return Math.max(5, Math.min(m, 30));
    }

    /**
     * Looks at how the last sessions felt (newest first, only entries that have a rating).
     * Returns -1 (make it gentler), 0 (keep it) or +1 (a little harder).
     */
    public static int adjustFromFeelings(List<String> newestFirst) {
        if (newestFirst == null || newestFirst.isEmpty()) return 0;
        String a = newestFirst.get(0);
        if (FEEL_UNWELL.equals(a)) return -1;
        if (newestFirst.size() < 2) return 0;
        String b = newestFirst.get(1);
        boolean aHard = FEEL_HARD.equals(a);
        boolean bHard = FEEL_HARD.equals(b) || FEEL_UNWELL.equals(b);
        if (aHard && bHard) return -1;
        if (FEEL_EASY.equals(a) && FEEL_EASY.equals(b)) return 1;
        return 0;
    }

    public static Plan build(Mode mode, String goal, String level, Set<String> limits,
                             Set<String> equipment, String duration, int feelingAdjust, long seed) {
        boolean tired = limits.contains(ProfileOptions.LIM_TIRED);
        boolean gentle = limits.contains(ProfileOptions.LIM_GENTLE);

        int cap = 3;
        if (ProfileOptions.LEVEL_START.equals(level)) cap = 2;
        if (tired) cap = Math.min(cap, 2);
        if (gentle) cap = 1;
        if (feelingAdjust < 0) cap = Math.max(1, cap - 1);
        else if (feelingAdjust > 0 && !tired && !gentle) cap = Math.min(3, cap + 1);

        int exSeconds = mode == Mode.YOGA ? 45 : 40;
        int rest = 10;
        if (tired || gentle) {
            exSeconds = exSeconds * 3 / 4;
            rest = 20;
        }
        if (feelingAdjust < 0) rest += 10;

        int minutes = parseMinutes(duration);
        int usable = minutes * 60 - GET_READY_SECONDS;
        int n = Math.max(3, (usable + rest) / (exSeconds + rest));
        int bookends = n <= 6 ? 1 : 2;

        Random rnd = new Random(seed);
        List<Exercise> warm = pool(mode, Phase.WARMUP, cap, limits, equipment);
        List<Exercise> cool = pool(mode, Phase.COOLDOWN, cap, limits, equipment);
        Collections.shuffle(warm, rnd);
        Collections.shuffle(cool, rnd);
        int warmCount = Math.min(bookends, warm.size());
        int coolCount = Math.min(bookends, cool.size());
        int mainCount = n - warmCount - coolCount;

        List<Exercise> mainPool = pool(mode, Phase.MAIN, cap, limits, equipment);
        final Map<Kind, Integer> priority = priorities(goal);
        final Map<Exercise, Integer> score = new java.util.HashMap<>();
        for (Exercise e : mainPool) {
            score.put(e, priority.get(e.kind) * 10 + rnd.nextInt(10));
        }
        Collections.sort(mainPool, new Comparator<Exercise>() {
            @Override
            public int compare(Exercise x, Exercise y) {
                int c = score.get(y) - score.get(x);
                return c != 0 ? c : x.id.compareTo(y.id);
            }
        });

        List<Item> items = new ArrayList<>();
        for (int i = 0; i < warmCount; i++) items.add(new Item(warm.get(i), 1));
        if (!mainPool.isEmpty()) {
            for (int i = 0; i < mainCount; i++) {
                items.add(new Item(mainPool.get(i % mainPool.size()), i / mainPool.size() + 1));
            }
        }
        for (int i = 0; i < coolCount; i++) items.add(new Item(cool.get(i), 1));

        List<String> notes = new ArrayList<>();
        if (cap == 1) {
            notes.add("Today's plan uses only very gentle movements.");
        }
        if (!limits.isEmpty()) {
            List<String> shown = new ArrayList<>();
            for (String l : limits) {
                if (!l.equals(ProfileOptions.LIM_TIRED) && !l.equals(ProfileOptions.LIM_GENTLE)) shown.add(l);
            }
            Collections.sort(shown);
            if (!shown.isEmpty()) {
                notes.add("Left out movements that can be hard with: " + join(shown) + ".");
            }
        }
        if (tired || gentle) {
            notes.add("Exercises are shorter and rests are longer.");
        }
        if (feelingAdjust < 0) {
            notes.add("Your last session felt hard or unwell, so today is gentler with longer rests.");
        } else if (feelingAdjust > 0 && !tired && !gentle) {
            notes.add("Your last sessions felt easy, so today is a little more challenging.");
        }
        if (!mainPool.isEmpty() && mainCount > mainPool.size()) {
            notes.add("Only " + mainPool.size() + " exercises suit your settings for this part, so some repeat as another round.");
        }
        if (mainPool.isEmpty()) {
            notes.add("No main exercises fit your current settings. You can adjust your profile and try again.");
        }
        return new Plan(mode, items, exSeconds, rest, cap, notes);
    }

    static List<Exercise> pool(Mode mode, Phase phase, int cap, Set<String> limits, Set<String> equipment) {
        List<Exercise> out = new ArrayList<>();
        for (Exercise e : ExerciseLibrary.all()) {
            if (!e.suits(mode) || e.phase != phase) continue;
            if (e.intensity > cap) continue;
            if (intersects(e.avoidIf, limits)) continue;
            if (!e.needsAny.isEmpty() && !intersects(e.needsAny, equipment)) continue;
            out.add(e);
        }
        return out;
    }

    private static boolean intersects(Set<String> a, Set<String> b) {
        for (String s : a) {
            if (b.contains(s)) return true;
        }
        return false;
    }

    private static Map<Kind, Integer> priorities(String goal) {
        Map<Kind, Integer> p = new EnumMap<>(Kind.class);
        int st = 1, ca = 1, mo = 1, cm = 1;
        if (ProfileOptions.GOAL_STRENGTH.equals(goal)) { st = 2; ca = 1; mo = 0; cm = 0; }
        else if (ProfileOptions.GOAL_STAMINA.equals(goal)) { ca = 2; st = 1; mo = 0; cm = 0; }
        else if (ProfileOptions.GOAL_FLEX.equals(goal)) { mo = 2; st = 1; ca = 0; cm = 1; }
        else if (ProfileOptions.GOAL_RELAX.equals(goal)) { cm = 2; mo = 1; st = 0; ca = 0; }
        else if (ProfileOptions.GOAL_INDEPENDENCE.equals(goal)) { st = 2; mo = 2; ca = 0; cm = 0; }
        p.put(Kind.STRENGTH, st);
        p.put(Kind.CARDIO, ca);
        p.put(Kind.MOBILITY, mo);
        p.put(Kind.CALM, cm);
        return p;
    }

    private static String join(List<String> parts) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(parts.get(i).toLowerCase());
        }
        return sb.toString();
    }
}
